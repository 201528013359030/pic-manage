<?php

namespace app\modules\leave\controllers;

use yii\web\Controller;
use app\models\LeaveHistory;
use app\models\Studentinfo;
use app\models\Teacherinfo;
use app\models\LeaveInstructor;
use app\models\IctWebService;
use app\models\LeaveAudit;
use app\models\LeaveUnit;
use app\models\LeaveSyllabus;
use app\models\LeaveRule;
use app\models\LeaveNotice;
use app\models\Leave;


class LeaveHistoryController extends Controller
{
    public $enableCsrfValidation = false;//yii默认表单csrf验证，如果post不带改参数会报错！
    public $layout  = false;
    public $typeStr = ["","事","病","婚","丧","年","其他"];
    public $typeIcon = ["","ic_shi","ic_ill","ic_marry","ic_die","ic_year","ic_other"];
    public $auditStr = ["","待审批","同意","拒绝","审批中","取消"];
    public $leaveNotice  = "请假通知";
    public $urlAudit = "/leave/web/index.php?r=leave/audit/content&uid=&eguid=&auth_token=&aid=";
    
    public function actionIndex()
    {
        return $this->render('index');
    }
    public function getAudit($major,$day){
    	if($day <=3 ){
    		return [];
    	}else if($day >= 15){
    		$day = 15;
    	}
    	$connection = \Yii::$app->db;
    	$command = $connection->createCommand('SELECT * FROM leave_rule  WHERE major="'.$major.'" and find_in_set("'.$day.'",leave_day)');
    	$audit = $command->queryAll();
    	if(count($audit) == 0){
    		$major = "其它专业";
    		$command = $connection->createCommand('SELECT * FROM leave_rule  WHERE major="'.$major.'" and find_in_set("'.$day.'",leave_day)');
    		$audit = $command->queryAll();
    	}
    	if(count($audit) > 0){
    		foreach($audit as $a){
    			$return[] = $a['teacher'];
    		}
    	}
    	return $return;
    }
    public function autoRejectLeaves($idarr){
    	//$todayStart = strtotime("today");
    	//$todayNight = $todayStart + 22*60*60;
    	$currentTime = time();
    	//echo "today=".$todayStart.",time=".time().",diff=".(time()-$todayStart)."<br>";
    	foreach($idarr as $id){
    		$reject = 0;    		
    		$leave = LeaveHistory::find()->where(['id'=>$id])->asArray()->one();
    		$startTime = $leave["start_time"];
    		$startTime0 = strtotime(date('Y-m-d',$startTime));
    		$startTimeNight = $startTime0 + 22*60*60;
    		//echo "id=".$id.",startTime=".$startTime.",startTime0=".$startTime0.",date=".date('Y-m-d H:i:s',$startTime)."<br>";
    		$leaveUnits = LeaveUnit::find()->where(['leave_id'=>$id])->orderBy('date,unit ASC')->asArray()->all();
    		//print_r($leaveUnits);
    		if(count($leaveUnits)>0){    			
    			$unit = $leaveUnits[0]["unit"];
    			//echo "unit=".$unit.",";
    			$unitTime = new Leave();
    			$unitStart = $unitTime->unitTime[$unit];
    			//echo "time=".$unitStart.",date=".date('Y-m-d H:i:s',$leaveUnits[0]["date"])."<br>";
    			//上课时间(前5分钟)若比请假第一天晚10点的时间大，就选择请假第一天晚10点拒绝请假条
    			if(($leaveUnits[0]["date"]+$unitStart-5*60)>$startTimeNight){
    				$rejectTime = $startTimeNight;
    			}else{
    				$rejectTime = ($startTime0+$unitStart-5*60);
    			}
    		}else{
    			//截至到晚10点自动拒绝；
    			$rejectTime = $startTimeNight;    						
    		}
    		if($currentTime>$rejectTime){
    			$reject = 1;
    			//处理流程
    			$processDefinitionKey = "LeaveBill";
    			$result = \Yii::$app->leavecomponent->getProcessInstances_businessKey($processDefinitionKey,$id);
    			if(isset($result["data"])&&count($result["data"])>0){
	    			$processInstanceId = $result["data"][0]["id"];
	    			$tasks = \Yii::$app->leavecomponent->getTasks($processInstanceId);
	    			//print_r($tasks);
	    			if(isset($tasks["data"])&&count($tasks["data"])>0){
		    			$taskId = $tasks["data"][0]["id"];
		    			$paramArr = array("0"=>array("name"=>"isAgree","value"=>"1"),
		    					"1"=>array("name"=>"auditUser","value"=>$leave["name"])
		    			);
		    			$result = \Yii::$app->leavecomponent->postTasks($taskId,$paramArr);
		    			//print_r($result);
	    			}
    			}
    			//处理业务表
    			$leaveHistory = LeaveHistory::findOne(['id'=>$id]);
    			//echo "leaveHistory:<br>";
    			//print_r($leaveHistory);
    			$leaveHistory->state = '3';
    			$leaveHistory->update_time = strval($rejectTime);
    			$leaveHistory->save();
    			$leaveAudit = LeaveAudit::find()->where(['leave_id'=>$id,'active'=>1])->all();
    			//print_r($leaveAudit);
    			foreach($leaveAudit as $audit){
	    			//echo "<br>audit:<br>";
	    			//print_r($audit);
	    			$audit->active = '6';
	    			$audit->state = '3';
	    			$audit->date = strval($rejectTime);
	    			$audit->save();
    			}
    			$leaveUnits = LeaveUnit::find()->where(['leave_id'=>$id])->all();
    			foreach($leaveUnits as $unit){
	    			//echo "<br>unit:<br>";
	    			//print_r($unit);
	    			$unit->status = '2';
	    			$unit->save();
    			}
    		}
    		
    	}
    	return;
    }
    public function actionList(){
    	$uid = \Yii::$app->request->get('uid');
    	//$leave = LeaveHistory::findAll(['uid'=>$uid]);
    	$activeLeaves = LeaveHistory::find()->where(["uid"=>$uid,"state"=>[1,4]])->asArray()->all();
    	//print_r($activeLeaves);
    	//判断是否已过期，过期则自动拒绝；
    	$ids = array();
    	$ids = array_map('array_shift', $activeLeaves);
    	//echo "count=".count($activeLeaves).",ids:<br>";
    	//print_r($ids);
    	$this->autoRejectLeaves($ids);
    	$leaveList = LeaveHistory::find()->where(["uid"=>$uid])->orderBy("create_time DESC")->asArray()->all();
    	//print_r($leave);
    	$historyList = array();
    	$h = 0;    	
    	$activeList = array();
    	$a = 0;
    	
    	
    	foreach ($leaveList as $key=>$leave ){
    		//if(strcasecmp($leave["state"], "5")){
    			if(strcasecmp($leave["state"], "5")==0 || strcasecmp($leave["state"], "2")==0 || strcasecmp($leave["state"], "3")==0){
	    			$historyList[$h++] = $leave;
	    		}else{
	    			$activeList[$a++] = $leave;   			
	    		}
    		//}
    		
    	}
    	//echo "history:<br>";
    	//print_r($historyList);
    	//echo "<br>active:<br>";
    	//print_r($activeList);
    	return $this->render('list',[
    			'historyList'=>$historyList,
    			'activeList'=>$activeList,
    			'typeStr'=>$this->typeStr,
    			'typeIcon'=>$this->typeIcon,
    			'auditStr'=>$this->auditStr,
    			'uid'=>$uid,
    			]);
    }
    public function actionDetail(){
    	$leaveId = \Yii::$app->request->get('leaveId');
    	$uid = \Yii::$app->request->get('uid');
    	$leaveInfo = LeaveHistory::find()->where(['id'=>$leaveId])->asArray()->one();
    	//print_r($leaveInfo);
    	$stud = Studentinfo::find()->where(['uid'=>$uid])->asArray()->one();
    	$auditCount = $this->getAudit($stud['major'],$leaveInfo['leave_day']);
    	$auditUser = LeaveAudit::find()->where(['leave_id'=>$leaveId,'active'=>[2,5,6]])->orderBy('id DESC')->asArray()->all();
    	//echo "audit:<br>";
    	//print_r($auditUser);
    	$stateCount = 0;
    	$tNo = false;
    	foreach($auditUser as $a){    		
    		$temp = [];
    		if(strcasecmp($a["active"], "5")==0){
    			$temp['info'] = $stud["sName"]."(本人) ".$this->auditStr[$a['active']]."  ".$a['opinion'];    	
    			$temp['time'] = date("Y-m-d H:i", $a['date']);
    			$workflow[] = $temp;
    			break;		
    		}else if(strcasecmp($a["active"], "6")==0){
    			$temp['info'] = "请假条过期，自动拒绝";
    			$temp['time'] = date("Y-m-d H:i", $a['date']);
    			$workflow[] = $temp;
    			//break;
    		}else{
    			$temp['info'] = $a['name']."(".$a['remark'].") ".$this->auditStr[$a['state']]."  ".$a['opinion'];
    			$temp['time'] = date("Y-m-d H:i", $a['date']);
    			$workflow[] = $temp;
    		}/**/
    		//$temp['info'] = $a['name']."(".$a['remark'].") ".$this->auditStr[$a['state']]."  ".$a['opinion'];
    		//$temp['time'] = date("Y-m-d H:i", $a['date']);
    		//$workflow[] = $temp;
    	}
    	$workflow[] = ['info'=>"创建请假条","time"=>date("Y-m-d H:i",$leaveInfo['create_time'])];
    	
    	$unit = LeaveUnit::find()->where(['leave_id'=>$leaveId])->asArray()->all();
    	//获取流程信息
    	$processDefinitionKey = "LeaveBill";
    	$process = \Yii::$app->leavecomponent->getProcessInstances_businessKey($processDefinitionKey,$leaveId);
    	//echo "<br>process:<br>";
    	//print_r($result);
    	$isInstructor = 1;
    	$task_name = "辅导员";
    	if(isset($process["data"])&&count($process["data"])>0){
    		$processInstanceId = $process["data"][0]["id"];
    		$tasks = \Yii::$app->leavecomponent->getTasks($processInstanceId);
    		//echo "<br>tasks:<br>";
    		//print_r($tasks);
    		if(isset($tasks["data"])&&count($tasks["data"])>0){
    			$task_name = $tasks["data"][0]["name"];
    			//echo "<br>task_name=".$task_name;
    			if(strcasecmp($task_name,"辅导员")){
    				$isInstructor = 0;
    			}
    		}
    	}
    	if($isInstructor){
    		//获取辅导员
	        $audit = LeaveInstructor::find()->where(['institute'=>$stud["institute"],'major'=>$stud["major"],'grade'=>$stud["year"].'级','class'=>$stud["grade"]])->asArray()->one();
	        //echo "stud:";
	        //print_r($stud);
	        //echo "audit:<br>";
	        //print_r($audit);
	        $t_name = $audit["instructor"];
	        $teacher = Teacherinfo::find()->where(['tNo'=>$audit["teacher_no"]])->asArray()->one();
	        //echo "teacher:<br>";
	        //print_r($teacher);
    	}else{
    		//获取其他审批人
    		$leaveRule = LeaveRule::find()->where(['major'=>$stud['major'],'remark'=>$task_name])->asArray()->one();
    		//echo "leaveRule:<br>";
    		//print_r($leaveRule);
    		$t_name = $leaveRule["teacher"];
    		$teacher = Teacherinfo::find()->where(['tNo'=>$leaveRule["teacher_no"]])->asArray()->one();
    	}
    	//echo "teacher:<br>";
    	//print_r($teacher);
    	//echo "is=".$isInstructor.",tname=".$t_name;
    	//current task
    	$currentTask = [];
    	//if(isset($process["data"])&&count($process["data"])>0){	 
    	if(strcasecmp($leaveInfo["state"], "1")==0 || strcasecmp($leaveInfo["state"], "4")==0){   	
	    	$currentTask['info'] = $t_name."(".$task_name.") 待审核";
	    	$currentTask['time'] = "";
	    	$ishistory = 0;
    	}else{
    		$ishistory = 1;
    	}
        return $this->render('detail',[
    			'leaveInfo'=>$leaveInfo,
    			'unit'=>$unit,
    			'workflow'=>$workflow,
    			'uid'=>$uid,
    			'leaveId'=>$leaveId,
        		'tUid'=>$teacher["uid"],
        		'isInstructor'=>$isInstructor,
        		'task_name'=>$task_name,
        		'currentTask'=>$currentTask,
        		'ishistory'=>$ishistory,
    			]);
    }
    public function actionCancel(){
    	$uid = \Yii::$app->request->post('uid');
    	$stud = Studentinfo::find()->where(['uid'=>$uid])->asArray()->one();
    	//print_r($stud);
    	$leaveId = \Yii::$app->request->post('leaveId');
    	//echo "uid=".$uid.",leaveId=".$leaveId."<br>";
    	//
    	$processDefinitionKey = "LeaveBill";
    	$result = \Yii::$app->leavecomponent->getProcessInstances_businessKey($processDefinitionKey,$leaveId);
    	if(isset($result["data"])&&count($result["data"])>0){
    		$processInstanceId = $result["data"][0]["id"];
    		$tasks = \Yii::$app->leavecomponent->getTasks($processInstanceId);
    		//print_r($tasks);
    		if(isset($tasks["data"])&&count($tasks["data"])>0){
    			$taskId = $tasks["data"][0]["id"];
    			$paramArr = array("0"=>array("name"=>"isAgree","value"=>"2"),
    					"1"=>array("name"=>"auditUser","value"=>$stud["sName"])
    			);
    			$result = \Yii::$app->leavecomponent->postTasks($taskId,$paramArr);
    			//print_r($result);
    		}
    	}
    	//处理业务表
    	$leaveHistory = LeaveHistory::findOne(['id'=>$leaveId]);
    	//echo "leaveHistory:<br>";
    	//print_r($leaveHistory);
    	$leaveHistory->state = '5';
    	$leaveHistory->update_time = strval(time());
    	$leaveHistory->save();
    	$leaveAudit = LeaveAudit::find()->where(['leave_id'=>$leaveId])->all();
    	foreach($leaveAudit as $audit){
    		//echo "<br>audit:<br>";
    		//print_r($audit);
    		$audit->active = '5';
    		$audit->state = '3';
    		$audit->date = strval(time());
    		$audit->save();
    	}
    	$leaveUnits = LeaveUnit::find()->where(['leave_id'=>$leaveId])->all();
    	foreach($leaveUnits as $unit){
    		//echo "<br>unit:<br>";
    		//print_r($unit);
    		$unit->status = '1';
    		$unit->save();
    	}
    	//return $this->render('index');
    	return $this->redirect(array('list','uid'=>$uid));
    }
    public function actionSendNotice(){
    	$uid = \Yii::$app->request->post('uid');
    	$stud = Studentinfo::find()->where(['uid'=>$uid])->asArray()->one();
    	$tUid = \Yii::$app->request->post('tUid');
    	//print_r($stud);
    	$leaveId = \Yii::$app->request->post('leaveId');
    	//echo "uid=".$uid.",id=".$leaveId;
    	//$url = "/leave/web/index.php?r=leave/leave-history/detail&uid=".$uid."&leaveId=".$leaveId;
    	$iws = new IctWebService();
    	$eid = explode("@",$uid);
    	$iws->eid = $eid[1];
    	$iws->getAdminToken();
    	$iws->lappNotice(8,$tUid,$this->leaveNotice,$this->urlAudit.$leaveId);
    	
    	return $this->redirect(['detail','uid'=>$uid,'leaveId'=>$leaveId]);
    }
}
