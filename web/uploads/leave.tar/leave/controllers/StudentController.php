<?php

namespace app\modules\leave\controllers;

use yii\web\Controller;
use app\models\LeaveHistory;
use app\models\Studentinfo;
use app\models\Teacherinfo;
use app\models\LeaveInstructor;
use app\models\IctWebService;
use app\models\LeaveAudit;
use app\models\LeaveUnit;
use app\models\LeaveSyllabus;
use app\models\LeaveNotice;
use app\models\LeaveTeacherinfo;
use app\models\Leave;


class StudentController extends Controller
{
    public $enableCsrfValidation = false;//yii默认表单csrf验证，如果post不带改参数会报错！
    public $layout  = false;
    public $startWeek = '2016-03-07';
    public $term = "2015-2016学年第二学期";
    public $processDefinitionKey  = "LeaveBill";
    public $leaveNotice  = "请假通知";
    public $urlAudit = "/leave/web/index.php?r=leave/audit/content&uid=&eguid=&auth_token=&aid=";
    public $infoUrl = "/leave/web/index.php?r=leave/audit/content&uid=&eguid=&auth_token=&flag=1&aid=";
    public $listUrl = "/leave/web/index.php?r=leave/leave-history/list&uid=&eguid=&auth_token=&flag=1&aid=";
    public $mobileNoticeContent = "请假通知，&user同学在&date[&unit]《&course》课程中请假";
    public function actionIndex()
    {
        return $this->render('index');
    }
    public function actionInfo()
    {
        $type = \Yii::$app->request->post('type');
        $reasons = \Yii::$app->request->post('reasons');
        $day = \Yii::$app->request->post('day');
        $startTime = (\Yii::$app->request->post('startTime'));
        $endTime = (\Yii::$app->request->post('endTime'));
        $uid = \Yii::$app->request->post('uid');
        if(!$uid){
            $uid = \Yii::$app->request->get('uid');
        }
        $types = ["请选择","事假","病假","婚假","丧假","年假","其他"];
     //   print_r($startTime);
      //  print_r($endTime);
        return $this->render('info',['type'=>$type,
                                    'reasons'=>$reasons,
                                    'day'=>$day,
                                    'startTime'=>$startTime,
                                    'endTime'=>$endTime,
                                    'uid'=>$uid,
                                    'types'=>$types]);
    }
    public function actionCreate()
    {
        $uid = \Yii::$app->request->post('uid');
        //$uid = '84225@83273';
        $startTime =strtotime(\Yii::$app->request->post('startTime'));
        $endTime = strtotime(\Yii::$app->request->post('endTime'));
        $type = \Yii::$app->request->post('type');
        if(!$type){
            $type = "6";
        }
        $reasons = \Yii::$app->request->post('reasons');
        $day = \Yii::$app->request->post('day');
        $user = Studentinfo::findOne(['uid'=>$uid]);
        if(!$user){
            throw new \yii\web\HttpException(200,'Invalid uid',20001);
        }
        $iws = new IctWebService();
        $iws->getAdminToken();
        $result = $iws->getNodeInfo($uid,['departmentnumber']);
        $class = $result['result']['0']['data']['departmentnumber'][0];
        $grade = substr($class,0,4);
        $connection = \Yii::$app->db;
        $array = ['','一','二','三','四','五','六','日'];
        $syllabusList = [];
        $time = $startTime;
        $createTime = time();
        $unitTime = new Leave();
        while($time <= $endTime){
            \Yii::info($time);
            $week = date('W',$time) - date('W',strtotime($this->startWeek))+1;//第几周
            $setsuji = $array[date('N',$time)];//星期几
            $command = $connection->createCommand('SELECT * FROM leave_syllabus WHERE grade="'.$grade.'" and institute="'.$user->institute.'" and major="'.$user->major.'"and class="'.$user->grade.'" and find_in_set("'.$week.'",week) and setsuji like "'.$setsuji.'%"'.' ORDER BY `leave_syllabus`.`setsuji` ASC');
    //        print_r($command);
            $syllabus = $command->queryAll();
            if($syllabus){
                //日期；单元；课程编号;
                $unitList = [];
                foreach($syllabus as $s){
                    $unit = $this->getUnit($s['setsuji']);
                    $unm = $s['course_no'];
                    foreach($unit as $k=>$u){
                        $s['setsujiStr'] = $u['setsuji'];
                        $uk = $u['unit'];
                        if($time+$unitTime->unitTime[$uk]-10*60 < $createTime){
                            continue;
                        }
                        $unitList[$uk][$unm] = $s;
                    }
                }
                $syllabusList[$time] = $unitList;
            }
            $time += 24*60*60;
        }
    //    print_r($syllabusList);
        return $this->render('unit',['startTime'=>$startTime,
                                    'uid'=>$uid,
                                    'type'=>$type,
                                    'reasons'=>$reasons,
                                    'day'=>$day,
                                    'syllabus'=>$syllabusList,
                                    'endTime'=>$endTime]);
    }
    public function actionSave(){
        $uid = \Yii::$app->request->post('uid');
        $time = \Yii::$app->request->post('startTime');
        $endTime = \Yii::$app->request->post('endTime');
        $unit = \Yii::$app->request->post('unit');
        $leaveTime = \Yii::$app->request->post('leaveTime');
        $leaveDay = \Yii::$app->request->post('day');
        $reasons = \Yii::$app->request->post('reasons');
        $type = \Yii::$app->request->post('type');
        $checkbox = \Yii::$app->request->post('checkbox');
        $setsuji = \Yii::$app->request->post('setsuji');
        $state = 1;
        $createTime = time();
        $user = Studentinfo::findOne(['uid'=>$uid]);
        $leave = new LeaveHistory();
        $leave->campus = "本校区"; 
        $leave->term = $this->term;
        $leave->uid = $uid;
        $leave->name = $user->sName;
        $leave->create_time = (string)time();
        $leave->start_time = $time;
        $leave->end_time = $endTime;
        $leave->leave_day = $leaveDay;
        $leave->leave_type = $type;
        $leave->reasons = $reasons;
        $leave->state = "1";
        $leave->workflow = 0;
        $leave->institute = $user->institute;
        $leave->major = $user->major;
        $leave->grade = $user->grade;
        $leave->year = $user->year;
        $flag = $leave->save();
        if(!$flag){
            \Yii::info($leave);
        }
     //   print_r($leave);
   //     print_r($unit);
        if(!$checkbox){
            $checkbox = [];
        }
        foreach($checkbox as $k=>$c){

            $courseAllInfo = $this->getCourse($leaveTime[$k],$user->institute,$user->major,$this->getGrade($uid),$unit[$k],$user->grade); 
        //    print_r($courseAllInfo);
            $teacher =[];
            $names =[];
            foreach($courseAllInfo as $c){
                $name = Teacherinfo::findOne(['tNo'=>$c['teacher']]);
                if(!$name){
                    $teacherMobile = LeaveTeacherinfo::findOne(["name"=>$c['name']]);
                    if($teacherMobile){
                        $notice = new LeaveNotice();
                        $notice->leave_id = $leave->id;
                        $notice->name = $c['name'];
                        $notice->mobile = $teacherMobile->mobile;
                        $mobileNoticeContent = str_replace("&user",$leave->name,$this->mobileNoticeContent);
                        $mobileNoticeContent = str_replace("&date",date("Y-m-d",$leaveTime[$k]),$mobileNoticeContent);
                        $mobileNoticeContent = str_replace("&unit",$setsuji[$k],$mobileNoticeContent);
                        $mobileNoticeContent = str_replace("&course",$courseAllInfo[0]['course'],$mobileNoticeContent);
                        $notice->content = $mobileNoticeContent;
                        if(!$notice->save()){
                            \Yii::info(['notice'=>$notice]);
                            print_r("error");
                        }
                    }
                    \Yii::info(['name'=>$c['name']]);
                }
        //        $name = Teacherinfo::findOne(['tNo'=>"266"]);
                $teacher[] = $c['teacher'];
                if(isset($c['name'])){
                    $names[] = $c['name'];
                }
            }
            if(count($names)== 0){
                //continue;
            }
            $leaveUnit = new LeaveUnit();
            $leaveUnit->leave_id = (string)$leave->id;
            $leaveUnit->date = $leaveTime[$k];
            $array = [];
            preg_match_all('/\d+/',$setsuji[$k],$array);
            $leaveUnit->unit = (string)(($array[0][0]+1)/2);
           // $unitArr = $this->getUnit($courseAllInfo[0]['setsuji']);
            //$leaveUnit->unit = (string)$unitArr[0]['unit'];
            $leaveUnit->setsuji = $setsuji[$k];
            $leaveUnit->course = $courseAllInfo[0]['course'];
            $leaveUnit->teacher_no = implode(',',$teacher);
            $leaveUnit->name = implode(',',$names);
            $leaveUnit->status = 2;
            if(!$leaveUnit->save()){
                \Yii::info($leaveUnit);
               // print_r('error');
            }
        }
        $instructor = $this->getInstructor($uid);
        $leaveAudit = new LeaveAudit();
        $leaveAudit->leave_id = (string)$leave->id;
        $leaveAudit->teacher_no = (string)$instructor['teacher_no'];
        $leaveAudit->name = $instructor['instructor'];
        //$leaveAudit->date = $leave->create_time;
        $leaveAudit->state  = "1" ;
        $leaveAudit->remark  = "辅导员" ;
        $leaveAudit->workflow  = "0";
        $leaveAudit->active  = 1;
        $leaveAudit->create_time  = $leave->create_time;
        $flag = $leaveAudit->save();
        if(!$flag){
            \Yii::info($leaveAudit);
        }

        //print_r($leaveAudit);
        $this->auditNotice($leaveAudit->teacher_no,false,$this->urlAudit.$leave->id);
        $audit = $this->getAudit($user->major,$leaveDay);    
        foreach($audit as $k=>$a){
            $leaveAudit = new LeaveAudit();
            $leaveAudit->leave_id = (string)$leave->id;
            $leaveAudit->teacher_no = (string)$a['teacher'];
            $leaveAudit->name = $a['name'];
          //  $leaveAudit->date = $leave->create_time;
            $leaveAudit->state  = "1" ;
            $leaveAudit->remark  = $a['remark'] ;
            $leaveAudit->workflow  = (string)($k+1);
            $leaveAudit->active  = 0;
            $leaveAudit->create_time  = $leave->create_time;
            $flag = $leaveAudit->save();
            if(!$flag){
                print_r($leaveAudit);
                \Yii::info($leaveAudit);
            }
        }
        $workflow = \Yii::$app->leavecomponent->postProcessInstances($this->processDefinitionKey,$leave->id,$leaveDay,$instructor['instructor']);
      //  print_r($workflow);
      $this->infoUrl = str_replace("&uid=","&uid=$uid",$this->infoUrl);
      $this->infoUrl = str_replace("&aid=","&aid=".$leave->id,$this->infoUrl);
      $this->listUrl = str_replace("&uid=","&uid=$uid",$this->listUrl);
      return $this->render("finish",['infoUrl'=>$this->infoUrl,'listUrl'=>$this->listUrl]);

    }
    public function auditNotice($teacher_no=false,$uid=false,$url=false){
       // $teacher_no="266";
        if(!$uid){
            $audit = Teacherinfo::findOne(['tNo'=>$teacher_no]);
            $uid = $audit->uid;
        }
       // print_r($audit);
        $iws = new IctWebService();
        $eid = explode("@",$uid);
        $iws->eid = $eid[1];
        $iws->getAdminToken();
        $iws->lappNotice(8,$uid,$this->leaveNotice,$url);
        return;
    }
    public function getUnit($str){
        //\Yii::info($str);
        preg_match_all('/\d+/',$str,$array);
        $array = $array[0];
        $return = [];
        $flag = true;
        if(!isset($array[1])){
            $flag = false;
            $array[1] = $array[0];
        }
        for($array[0];$array[0] <= $array[1];$array[0]++ ){
            if(($array[0]+1)%2 == 0 ){
                $return[] =['unit'=>($array[0]+1)/2,'setsuji'=>$array[0].($flag?"-".($array[0]+1):"").'节'];
            }     
        }
        return $return;
    }
    public function getCourse($time,$institute,$major,$grade,$courseNo=false,$class=null){
        $array = ['','一','二','三','四','五','六','日'];
        $week = date('W',$time) - date('W',strtotime($this->startWeek))-1;//第几周
        $setsuji = $array[date('N',$time)];//星期几
        $connection = \Yii::$app->db;
        if($courseNo){
            $command = $connection->createCommand('SELECT * FROM leave_syllabus WHERE grade="'.$grade.'" and institute="'.$institute.'" and major="'.$major.'"and class="'.$class.'" and find_in_set("'.$week.'",week) and setsuji like "'.$setsuji.'%" and course_no="'.$courseNo.'"');
        
        }else{
            $command = $connection->createCommand('SELECT * FROM leave_syllabus WHERE grade="'.$grade.'" and institute="'.$institute.'" and major="'.$major.'"and class="'.$class.'" and find_in_set("'.$week.'",week) and setsuji like "'.$setsuji.'%"');
        }
        //print_r($command);
        $syllabus = $command->queryAll();
        return $syllabus;
    }
    public function getGrade($uid){
        $iws = new IctWebService();
        $iws->getAdminToken();
        $result = $iws->getNodeInfo($uid,['departmentnumber']);
        $class = $result['result']['0']['data']['departmentnumber'][0];
        $grade = substr($class,0,4);
        return $grade;
    }
    public function getInstructor($uid){
        $user = Studentinfo::findOne(['uid'=>$uid]);
        $grade = $this->getGrade($uid);
        if(!$user){
            throw new \yii\web\HttpException(200,'Invalid uid',20001);
        }
        $connection = \Yii::$app->db;
        $command = $connection->createCommand('SELECT * FROM leave_instructor WHERE grade="'.$grade.'级" and institute="'.$user->institute.'" and major="'.$user->major.'" and class="'.$user->grade.'"');
        $instructor = $command->queryOne();
     //   print_r($instructor);
        
        return $instructor;
         
    }
    public function getAudit($major,$day){
        if($day <=3 ){
            return [];
        }else if($day >= 15){
            $day = 15;
        }
        $connection = \Yii::$app->db;
        $command = $connection->createCommand('SELECT * FROM leave_rule  WHERE major="'.$major.'" and find_in_set("'.$day.'",leave_day)');
        $audit = $command->queryAll();
        if(count($audit) == 0){
            $major = "其它专业";
            $command = $connection->createCommand('SELECT * FROM leave_rule  WHERE major="'.$major.'" and find_in_set("'.$day.'",leave_day)');
            $audit = $command->queryAll();
        }
        if(count($audit) > 0){
            foreach($audit as $a){
                $return[] = ['teacher'=>$a['teacher_no'],'remark'=>$a['remark'],'name'=>$a['teacher']];
            }
        }
        return $return;
    }
}
