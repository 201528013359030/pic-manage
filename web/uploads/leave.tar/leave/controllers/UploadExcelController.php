<?php

namespace app\modules\leave\controllers;
use yii\web\Controller;
use app\models\UploadForm;
use yii\web\UploadedFile;
use app\models\LeaveSyllabus;
use \PHPExcel_Style_NumberFormat;
class UploadExcelController extends Controller
{
    public function actionIndex()
    {
    	$model = new UploadForm();     //实例化上传model
  /* 	print_r(\Yii::$app->request->post());
    	return ; */
    	if ($model->load(\Yii::$app->request->post())) {
    
    		$model->file = UploadedFile::getInstances($model, 'file');
    
//     		$file = UploadedFile::getInstance($model, 'file');
 			$path='uploads/'.date("Ymd",time()).'/';   //建立文件夹
// 				$path='uploads/';
    		if ($model->file && $model->validate()) {
    			if(!file_exists($path)){
    				mkdir($path,'777');
    			}
    		exec('sudo cd /usr/local/www/nginx/html/ictHe/web;sudo chmod -R 777 uploads/'.date("Ymd",time()).'/');
    		$nextpath='uploads/'.date("Ymd",time()).'/'.time().'/';  
    		if(!file_exists($nextpath)){
    			mkdir($nextpath,'777');
    		}
    			exec("sudo cd /usr/local/www/nginx/html/ictHe/web;sudo chmod -R 777 uploads/");
    			foreach ($model->file as $file){
    				$_model = new UploadForm();             
    				$_model->file = $file;
    				$_model->file->saveAs($nextpath .mt_rand(1100,9900). time(). '.' . $_model->file->extension);				
    			}
    			\Yii::$app->session->setFlash('success','上传成功！');
    			if(is_dir($nextpath)){
    				if ($handle = opendir($nextpath)) {
    					$numflag=0;
    					$currentsum=0;
    					while (false !== ($file = readdir($handle))) {
    						if ($file != "." && $file != ".." && (strstr($file,'.xls')||strstr($file,'.xlsx'))) {                      //获取了文件的名字
//     							print_r($file);
//     							return ;
    							/**
    							 * 处理excel数据
    							 */
    							   
    							$fileexcel = $nextpath.$file;
    							 $sheet = 0; // 默认第一个sheet
    							$objPHPExcel = \PHPExcel_IOFactory::load($fileexcel);                                   //读取文件
    							// 当前的Sheet表
    							$currentSheet = $objPHPExcel->getSheet($sheet);
    							
    							// 一共多少列,值原为字母，转换成A为0，B为1的数字形式
    							$maxColumn = $currentSheet->getHighestColumn(); // 最大的列，A~Z，AA~AZ....
    							// 如果列数很大，需要做特殊处理,一般不会超过AAA列，因为实在太大，不考虑此种情况，只考虑AA形式的
    							if (strlen($maxColumn) > 1) {
    							$allColumn = (ord(substr($maxColumn, 0, 1)) - 64) * 26 + ord(substr($maxColumn, 1, 2)) - 65;
    							} else {
    							$allColumn = ord($currentSheet->getHighestColumn()) - 65;
    							}
    							$allRow = $currentSheet->getHighestRow();               //一共有多少行
    							$flag=0; 
    							$currentsum=$allRow-7;
    						/* 	print_r($allRow);
    							return; */
                                $deleteCourse = true;
    							for ($currentRow = 5; $currentRow <= $allRow-3; $currentRow++) {
    							unset($Leavemodel);
    							$Leavemodel=new LeaveSyllabus();
    							$term="2015-2016学年第二学期";
    							$Leavemodel->term=$term;                                                      //学年学期
    							//在第3行读出校区、学院、专业、班级
    							$campus=$currentSheet->getCellByColumnAndRow(1, 3)->getValue();
    							$campuslist=explode("：",$campus);
    							$campusstr=$campuslist[1];
    							$tmplist=explode(" ",$campusstr);
    							$campus=$tmplist[0];
    							$Leavemodel->campus=$campus;                                    //校区
    							$institute=$currentSheet->getCellByColumnAndRow(2, 3)->getValue();
    							$Leavemodel->institute=$institute;                                  //学院
    							$major=$currentSheet->getCellByColumnAndRow(9, 3)->getValue();
    							$majorlist=explode("：",$major);
    							$major=$majorlist[1];
    							$Leavemodel->major=$major;                                             //专业
    							$classstr=$currentSheet->getCellByColumnAndRow(13, 3)->getValue();
    							//截取前两位，为年级：
    							$grade="20".substr($classstr,0,2);
    							//班级截取倒数第二个字符
//     							$class=mb_substr($classstr,-2,-1,'utf-8');                              //用substr输出乱码
    							$class=substr($classstr,2,strlen($classstr)-1);
    							$str=trim($class);
    						
    							$result='';
    							for($i=0;$i<strlen($str);$i++){
    								if(is_numeric($str[$i])){
    									$result.=$str[$i];
    								}
    							}
    				
//     							$class=substr($class,1,1);
//     							$class=iconv('utf-8','gbk',$class);
    						/* 	print_r($result);
    							return ;  */
    							$Leavemodel->grade=$grade;                                             //年级
    							$Leavemodel->class=$result;                                                 //班级
                                //情况这个班级课程表，循环中只执行一次。
                                if($deleteCourse){
                                    $this->deleteCourse($Leavemodel);
                                    $deleteCourse = false;
                                }
                             //   return ;
    							$row = [];
    							for ($currentCol = 1; $currentCol <= $allColumn ; $currentCol++) {          //遍历每列
    							$currentcellValue = $currentSheet->getCellByColumnAndRow($currentCol, $currentRow)->getValue();
    							$row[]=$currentcellValue;
    							 
    							if($currentCol==1){
    							if(isset($currentcellValue)){
    							$tmplist=explode("]",$currentcellValue);
    							$course_no=substr($tmplist[0],1,strlen($tmplist[0])-1);
    							$course=$tmplist[1];
    							$Leavemodel->course=$course;
    							$Leavemodel->course_no=$course_no;
    							}else{
    							$Leavemodel->course=NULL;
    							$Leavemodel->course_no=NULL;
    							}
    							
    							}
    							if($currentCol==9){                             //课程类别
    							if(isset($currentcellValue)){
    							$tmplist=explode(" ",$currentcellValue);
    							$Leavemodel->course_type=$tmplist[0];
    							$Leavemodel->course_classes=$tmplist[1];
    							}else{
    							$Leavemodel->course_type=NULL;
    							$Leavemodel->course_classes=NULL;
    							}
    								
    							}
    							if($currentCol==10){
    							if(isset($currentcellValue)){
    							$tmplist=explode("]",$currentcellValue);
    							$teacher_no=substr($tmplist[0],1,strlen($tmplist[0])-1);
    							$teacher_name=$tmplist[1];
    							//     						$teacher_name=$tmplist[1];
    							$Leavemodel->teacher=$teacher_no;                        //教师编号
    							$Leavemodel->name=$teacher_name;
    							}else{
    							$Leavemodel->teacher=NULL;
    							$Leavemodel->name=NULL;
    							}
    							}
    							if($currentCol==13){
    							$week = [];
                                $weekArr1 = explode(',', $currentcellValue);
                                foreach ($weekArr1 as $key => $value) {
                                    $weekArr2 = explode('-', $value);
                                    if(isset($weekArr2[1])){
                                        for ($i=$weekArr2[0]; $i <= $weekArr2[1] ; $i++) { 
                                            $week[] = $i ;
                                        }
                                    }else{
                                        $week[] = $weekArr2[0] ;
                                    }

                                }
    							$Leavemodel->week=implode(',', $week);
    							}
    							
    							}
    							$Leavemodel->credit=isset($row[1])?(string)$row[1]:NULL;               //学分
    							$Leavemodel->hours=isset($row[2])?(string)$row[2]:NULL;               //学时
    							$Leavemodel->teach_hours=isset($row[3])?(string)$row[3]:NULL;   //讲授学时
    							$Leavemodel->experiment_hours=isset($row[4])?(string)$row[4]:NULL;  //试验学时
    							$Leavemodel->evaluation=isset($row[7])?(string)$row[7]:NULL;                   //考察方式
    							$Leavemodel->class_code=isset($row[10])?(string)$row[10]:NULL;                   //上课班号
    							$Leavemodel->course_number=isset($row[11])?(string)$row[11]:NULL;           //上课人数
    							$Leavemodel->setsuji=isset($row[13])?(string)$row[13]:NULL;
    							if($Leavemodel->save()){
    							 
    							}else{
    							var_dump($Leavemodel->getErrors());
    							return;
    							}
    							$flag++;
    							//                    		$rowlist[] = $row;
    							} 
    							$numflag+=$currentsum;
    						}
    						
    					}
    					file_put_contents("/tmp/import.log", "sumnum  is : " .'conf_psw'. "\n", $numflag);
//     					file_put_contents("/tmp/import.txt", "sumnum:".$numflag);
    					closedir($handle);
    				}
    			}
    		
    		}
    	}
        return $this->render('index',[
                'model' => $model]);
    }
    function deleteCourse($model){
        $result = LeaveSyllabus::deleteAll('institute = :institute AND major = :major AND grade = :grade AND class = :class', 
            [':institute' => $model->institute, ':major' => $model->major, ':grade' => $model->grade, ':class' => $model->class]);
        return $result;

    }


}
