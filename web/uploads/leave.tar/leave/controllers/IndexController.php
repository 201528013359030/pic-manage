<?php

namespace app\modules\leave\controllers;

use yii\web\Controller;
use app\models\Studentinfo;
use app\models\Teacherinfo;
use app\models\LeaveInstructor;
use app\models\LeaveRule;

class IndexController extends Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }
    public function actionRole()
    {
        $uid = \Yii::$app->request->get('uid');
        $user = Teacherinfo::findOne(["uid"=>$uid]);
        if($user){
            //审核人（院系领导）
            $role = LeaveRule::findOne(["teacher_no"=>$user->tNo]);
            if($role){
                return $this->redirect(array('audit/list','uid'=>$uid));
            }
            //审核人（辅导员）
            $role = LeaveInstructor::findOne(["teacher_no"=>$user->tNo]);
            if($role){
                return $this->redirect(array('audit/list','uid'=>$uid));
            }
            //任课教师
            $role = Teacherinfo::findOne(["tNo"=>$user->tNo]);
            if($role){
                return $this->redirect(array('leave-instructor/index','tid'=>$user->tNo));
            }
        }
        //学生
        $role = Studentinfo::findOne(["uid"=>$uid]);
        if($role){
            return $this->redirect(array('leave-history/list','uid'=>$uid));
        }
    }
}
