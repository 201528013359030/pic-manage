<?php

namespace app\modules\leave\controllers;

use yii\web\Controller;
use app\models\LeaveHistory;
use app\models\Studentinfo;
use app\models\Teacherinfo;
use app\models\LeaveInstructor;
use app\models\IctWebService;
use app\models\LeaveAudit;
use app\models\LeaveUnit;
use app\models\LeaveSyllabus;
use app\models\LeaveNotice;
use app\modules\leave\controllers\LeaveHistoryController;


class AuditController extends Controller
{
    public $enableCsrfValidation = false;//yii默认表单csrf验证，如果post不带改参数会报错！
    public $layout  = false;
    public $startWeek = '2016-03-07';
    public $term = "2015-2016学年第二学期";
    public $processDefinitionKey  = "LeaveBill";
    public $leaveNotice  = "请假通知";
    public $typeStr = ["其它","事","病","婚","丧","年","其他"];
    public $auditStr = ["","待审批","同意","拒绝","审批中","已取消","已过期"];
    public $urlAudit = "/leave/web/index.php?r=leave/audit/content&uid=&eguid=&auth_token=&aid=";
    public $urlUser ="/leave/web/index.php?r=leave/audit/content&uid=&eguid=&auth_token=&flag=1&aid=";
    public $iconStr = ["ic_other","ic_shi","ic_ill","ic_marry","ic_die","ic_year","ic_other"];
    public $echartInstitute = "/leave/web/index.php?r=leave/echart/institute";
    public function actionResult(){
        $aid = \Yii::$app->request->post('aid');
        $uid = \Yii::$app->request->post('uid');
        $tNo = \Yii::$app->request->post('tNo');
        $state = \Yii::$app->request->post('state');
        $isEnd = \Yii::$app->request->post('isEnd');
        $opinion = \Yii::$app->request->post('opinion');
     //   print_r($tNo);
        $audit = LeaveAudit::findOne(['leave_id'=>$aid,"teacher_no"=>$tNo,'active'=>1]);
        $leave = LeaveHistory::findOne($aid);
      //  print_r($audit);
        $audit->active = 2;
        $audit->opinion =$opinion ;
        $audit->date = (string)time();
        if($state == 3){
            $flag = 0;
            $audit->state = "3";
            $leave->state = "3";
            $this->auditNotice(false,$leave->uid,$this->urlUser.$leave->id,"请假已拒绝");
        }elseif($state == 2){
            $flag = 1;
            $audit->state = "2";
            if($isEnd){
                $this->auditNotice(false,$leave->uid,$this->urlUser.$leave->id,"请假已同意");
                $leave->state = "2";
                $leave->save();
                $this->teacherNotice($leave->id);
                $this->mobileNotice($leave->id);
            }else{
                $leave->state = "4";
                $nextAudit = LeaveAudit::findOne(['leave_id'=>$aid,"workflow"=>$audit->workflow+1]);
                $this->auditNotice($nextAudit->teacher_no,false,$this->urlAudit.$leave->id);
                $nextAudit->active = 1;
                $nextAudit->save();
            }
        }
        $result = \Yii::$app->leavecomponent->getProcessInstances_businessKey($this->processDefinitionKey,$leave->id);
        if(isset($result["data"])&&count($result["data"])>0){
            $processInstanceId = $result["data"][0]["id"];
            $tasks = \Yii::$app->leavecomponent->getTasks($processInstanceId);
            if(isset($tasks["data"])&&count($tasks["data"])>0){
                $taskId = $tasks["data"][0]["id"];
                $paramArr = array("0"=>array("name"=>"isAgree","value"=>"$flag"),
                                    "1"=>array("name"=>"auditUser","value"=>$audit->name)
                                );
                $result = \Yii::$app->leavecomponent->postTasks($taskId,$paramArr);
            }
        }
        $leave->save();
        $audit->save();
        return $this->redirect(array('list','uid'=>$uid));
    }
    public function actionContent(){
        $aid = \Yii::$app->request->get('aid');
        $uid = \Yii::$app->request->get('uid');
        $flag = \Yii::$app->request->get('flag');
        $t = \Yii::$app->request->get('t');
  //      $leave = LeaveHistory::findOne($aid);
        $leave = LeaveHistory::find()->joinWith('user')->where(["id"=>$aid])->asArray()->one();
        $auditCount = $this->getAudit($leave['user']['major'],$leave['leave_day']);
        $auditUser = LeaveAudit::find()->where(['leave_id'=>$aid])->orderBy('id DESC')->asArray()->all();
        $userInfo = Teacherinfo::findOne(['uid'=>$uid]);
        $stateCount = 0;
        $tNo = false;
        $isActive = false;
    //    print_r($auditUser);
        $workflowEnd = false;
        foreach($auditUser as $a){
            $temp = [];
            if($a['state'] == 2){
                $stateCount ++;
            }elseif($a['state'] == 3){
                $workflowEnd = true;
            }
            if($a['active'] == 1){
                $tNo = $a['teacher_no'];
                $temp['active'] = 1;
            }
            if($flag){

            }else{
                if($a['active'] == 1 && $a['teacher_no'] == $userInfo->tNo){
                    $isActive = true;
                }
            }
            if($leave['state'] == 5){
                $temp['info'] = $a['name']."(".$a['remark'].")" ;
                $temp['time'] = "";
            }elseif($a['active'] == 6){
                $temp['info'] = $a['name']."(".$a['remark'].") "."已过期,自动拒绝";
                $temp['time'] = $a['date']?date("Y-m-d H:i", $a['date']):"";
            }else{
                $temp['info'] = $a['name']."(".$a['remark'].") ".$this->auditStr[$a['state']]."  ".$a['opinion'];
                $temp['time'] = $a['date']?date("Y-m-d H:i", $a['date']):"";
            }
            $workflow[] = $temp; 
        }
        if($leave['state'] == 5){
            $workflow[] = ['info'=>"取消请假条","time"=>date("Y-m-d H:i",$leave['update_time'])];
        }
        $workflow[] = ['info'=>"创建请假条","time"=>date("Y-m-d H:i",$leave['create_time'])];
        $isEnd = false;
        if(count($auditCount) == $stateCount){ 
            $isEnd = true;
        }
        $unit = LeaveUnit::find()->where(['leave_id'=>$aid])->asArray()->all();
        return $this->render('content',['leave'=>$leave,
                                    'isEnd'=>$isEnd,
                                    'workflow'=>$workflow,
                                    'unit'=>$unit,
                                    'uid'=>$uid,
                                    'uidMsg'=>$leave['uid'],
                                    'aid'=>$aid,
                                    'tNo'=>$tNo,
                                    'flag'=>$flag,
                                    't'=>$t,
                                    'isActive'=>$isActive,
                                    'auditCount'=>count($auditCount),
                                    'mobile'=>$leave['user']['mobile'],
                                    ]);
        
    }
    public function actionList()
    {
        $uid = \Yii::$app->request->get('uid');
        //$uid = '85631@83273';
        $user = Teacherinfo::findOne(['uid'=>$uid]);
        $action = LeaveAudit::find()->where(['teacher_no'=>$user->tNo])->orderBy('create_time desc')->asArray()->all();
        $leave['content'] = [];
        $list['audit'] = [];
        $list['state'] = [];
        $leaveIdList = [];
        foreach($action as $a){
            $leaveIdList[] = $a['leave_id'];
        }
        $leaveList = LeaveHistory::find()->where(['id'=>$leaveIdList,"state"=>['1','4']])->asArray()->all();
        $ids = [];
        foreach($leaveList as $l){
            $ids[] = $l['id'];
        }
       // print_r($ids);
        $reject = new LeaveHistoryController(null,null);
        $reject->autoRejectLeaves($ids);

        foreach($action as $a){
            $leave = LeaveHistory::find()->where(['id'=>$a['leave_id']])->asArray()->one();
            if($a['state'] == 1){
                if($a['active'] == 2 || $a['active'] == 1){
                    $leave['content'] = "index.php?r=leave/audit/content&uid=$uid&aid=".$a['leave_id'];
                    $leave['state'] = 1;
                    $list['audit'][] = $leave;
                }else{
                //    $leave['content'] = "index.php?r=leave/audit/content&aid=".$a['leave_id'];
                 //   $list['state'][] = $leave; 
                }
            }else{
                if($a['active'] == 5 ){
                    if($a['workflow'] == 0){
                        $leave['content'] = "index.php?r=leave/audit/content&uid=$uid&aid=".$a['leave_id']."&flag=1";
                    }else{
                        continue;
                    }
                }elseif($a['active'] == 6){
                    $leave['content'] = "index.php?r=leave/audit/content&uid=$uid&aid=".$a['leave_id']."&flag=1";
                    $leave['state'] = 6;
                }else{
                    $leave['content'] = "index.php?r=leave/audit/content&uid=$uid&aid=".$a['leave_id'];
                }
                $list['state'][] = $leave; 
            }
        }
      //  print_r($list['audit']);
        return $this->render('list',['list'=>$list,
                                    'typeStr'=>$this->typeStr,
                                    'iconStr'=>$this->iconStr,
                                    'echart'=>$this->echartInstitute,
                                    'auditStr'=>$this->auditStr]);
    }
    public function actionIndex()
    {
        return $this->render('index');
    }
    public function auditNotice($teacher_no=false,$uid=false,$url=false,$content=false){
      //  $teacher_no="266";
        if(!$uid){
            $audit = Teacherinfo::findOne(['tNo'=>$teacher_no]);
            if(!$audit){
                return;
            }
            $uid = $audit->uid;
        }
       // print_r($audit);
        $iws = new IctWebService();
        $eid = explode("@",$uid);
        $iws->eid = $eid[1];
        $iws->getAdminToken();
        if(!$content){
            $content = $this->leaveNotice; 
        }
        $iws->lappNotice(8,$uid,$content,$url);
        return;
    }
    public function mobileNotice($aid){
        $noticeList = LeaveNotice::find()->where(['leave_id'=>$aid])->asArray()->all();
        $iws = new IctWebService();
        if(count($noticeList)>0){
            foreach($noticeList as $n){
                $mobile = $n['mobile'];
                //$iws->send_message_via_hevision(["18900923392"],$n['content']); 
            }
        }

    }
    public function teacherNotice($aid){
        $unit = LeaveUnit::find()->where(['leave_id'=>$aid])->all();
        $teacher = [];
        foreach($unit as $u){
            $temp = []; 
            $temp = explode(",",$u->teacher_no); 
            $u->status = 0;
            $u->save();
            foreach($temp as $t){
                if(!in_array($t,$teacher)){
                    $teacher[] = $t;
                    $this->auditNotice($t,false,$this->urlUser.$aid."&t=1");
                }  
            }
        }
        return;
    }
    public function getUnit($str){
        preg_match_all('/\d+/',$str,$array);
        $array = $array[0];
        $return = [];
        for($array[0];$array[0] <= $array[1];$array[0]++ ){
            if(($array[0]+1)%2 == 0 ){
                $return[] =['unit'=>($array[0]+1)/2,'setsuji'=>$array[0]."-".($array[0]+1).'节'];
            }     
        }
        return $return;
    }
    public function getCourse($time,$institute,$major,$grade,$courseNo=false){
        $array = ['','一','二','三','四','五','六','日'];
        $week = date('W',$time) - date('W',strtotime($this->startWeek))-1;//第几周
        $setsuji = $array[date('N',$time)];//星期几
        $connection = \Yii::$app->db;
        if($courseNo){
            $command = $connection->createCommand('SELECT * FROM leave_syllabus WHERE grade="'.$grade.'" and institute="'.$institute.'" and major="'.$major.'" and find_in_set("'.$week.'",week) and setsuji like "'.$setsuji.'%" and course_no="'.$courseNo.'"');
        
        }else{
            $command = $connection->createCommand('SELECT * FROM leave_syllabus WHERE grade="'.$grade.'" and institute="'.$institute.'" and major="'.$major.'" and find_in_set("'.$week.'",week) and setsuji like "'.$setsuji.'%"');
        }
        //print_r($command);
        $syllabus = $command->queryAll();
        return $syllabus;
    }
    public function getGrade($uid){
        $iws = new IctWebService();
        $iws->getAdminToken();
        $result = $iws->getNodeInfo($uid,['departmentnumber']);
        $class = $result['result']['0']['data']['departmentnumber'][0];
        $grade = substr($class,0,4);
        return $grade;
    }
    public function getInstructor($uid){
        $user = Studentinfo::findOne(['uid'=>$uid]);
        $grade = $this->getGrade($uid);
        if(!$user){
            throw new \yii\web\HttpException(200,'Invalid uid',20001);
        }
        $connection = \Yii::$app->db;
        $command = $connection->createCommand('SELECT * FROM leave_instructor WHERE grade="'.$grade.'级" and institute="'.$user->institute.'" and major="'.$user->major.'" and class="'.$user->grade.'"');
        $instructor = $command->queryOne();
      //  print_r($instructor);
        
        return $instructor;
         
    }
    public function getAudit($major,$day){
        if($day <=3 ){
            return [];
        }else if($day >= 15){
            $day = 15;
        }
        $connection = \Yii::$app->db;
        $command = $connection->createCommand('SELECT * FROM leave_rule  WHERE major="'.$major.'" and find_in_set("'.$day.'",leave_day)');
        $audit = $command->queryAll();
        if(count($audit) == 0){
            $major = "其它专业";
            $command = $connection->createCommand('SELECT * FROM leave_rule  WHERE major="'.$major.'" and find_in_set("'.$day.'",leave_day)');
            $audit = $command->queryAll();
        }
        if(count($audit) > 0){
            foreach($audit as $a){
                $return[] = $a['teacher'];
            }
        }
        return $return;
    }
}
