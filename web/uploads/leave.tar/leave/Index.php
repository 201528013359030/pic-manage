<?php

namespace app\modules\leave;

class Index extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\leave\controllers';

    public function init()
    {
        parent::init();
        header("Content-type:text/html;charset=utf-8"); 

        // custom initialization code goes here
    }
}
