<?php
/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\web\View;
use yii\widgets\ActiveForm;
?>

<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
		<title>请假列表</title>
		<?=Html::cssFile('@web/css/mydoc.css')?>
	</head>
	<body>
	<div class="off-canvas-wrap" data-offcanvas>
		<div class="inner-wrap">
            <div class="row-bt-button">
                   <a href="index.php?r=leave/echart/index">查看统计</a>
            </div>
			<div class="row">
				<ul class="tabs zzy_tabs" data-tab>
					<li class="tab-title small-6 small-collapse active"><a href="#panel1">今日</a></li>
					<li class="tab-title small-6 small-collapse"><a href="#panel2">本周</a></li>
				</ul>
			</div>
			<div class="row-tab-thin"></div>
				<div class="tabs-content">
				<!--panel1 为今日的请假情况-->
					<div class="active content" id="panel1">
						<ul class="accordion accordion-table">
						<!--在此添加循环-->
						 <?php foreach($stuList as $stu):?>
						  	
							<li class="accordion-navigation ">
								<a href="#panel1a" class="accordion-iteam">
									<span class="fr">人</span><span class="fr num fb"><?php echo count($stu)?></span>
									<span class="fr type"><?=$stu[0]['setsuji']?></span>
									<i class="ficon icon-caret-right"></i>
									<span class="fb"><?=$stu[0]['year']?><?=$stu[0]['major']?><?=$stu[0]['grade']."班"?></span>
									<span><?=$stu[0]['course']?></span>
								</a>
								<div id="panel1a" class="content active">
									<div class="list-group zzy-list">
										<!--a为要循环的内容包含 图标 状态请假日期 和请假人等-->
										<?php foreach($stu as $substu):?>
										<a href="index.php?r=leave/audit/content&aid=<?=$substu['leave_id']?>&flag=1&t=1" class="listIteam ">
								
											<i class="icon <?=$typeclass[$substu['leave_type']]?>"><?=$typeStr[$substu['leave_type']]?></i>
											<i class="ficon icon-angle-right"></i>
											<p class="info clearfix">
												<span class="fl name"><span><?=$substu['sName']?></span><span><?=$substu['leave_day']."天假"?></span></span>
											</p>
											<p class="info clearfix zzy_info">
												<span class="fl date"><?=$substu['reasons']?></span>
											</p>
										</a>
						
										 <?php endforeach?>
									</div>
									<!-- list group end-->
									<div></div>
							</li>			
							 <?php endforeach?>
						</ul>
					</div>
						<!-- panel1 end-->
						<div class="content" id="panel2">
							 <?php foreach($w_stu_array as $key=>$week):?>
							<div class="row-tab-half"><span class="fcf"><?=mb_substr($key, 0,2,'utf-8')?></span></div>
							
							<ul class="accordion accordion-table" data-accordion>
							<?php foreach($week as $subkey=>$wstu):?>
								<li class="accordion-navigation ">
									 
									<a href="#panel<?=mb_substr($key, 2,1,'utf-8')?><?=$subkey ?>a" class="accordion-iteam">
										<span class="fr">人</span><span class="fr num fb"><?=count($wstu)?></span>
										<span class="fr type"><?=$wstu[0]['setsuji']?></span>
										<i class="ficon icon-caret-right"></i>
										<span class="fb"><?=$wstu[0]["year"]?><?=$wstu[0]["major"]?><?=$wstu[0]["grade"]."班"?></span>
										<span><?=$wstu[0]["course"]?></span>
									</a>
									<div id="panel<?=mb_substr($key, 2,1,'utf-8')?><?=$subkey ?>a" class="content">
										<div class="list-group zzy-list">
											<!--a为要循环的内容包含 图标 状态请假日期 和请假人等-->
										 <?php foreach($wstu as $subkey1=>$value):?>
										
											<a href="index.php?r=leave/audit/content&aid=<?=$value['leave_id']?>&flag=1&t=1" class="listIteam">
												<i class="icon  <?=$typeclass[$value['leave_type']]?>"><?=$typeStr[$value['leave_type']]?></i>
												<i class="ficon icon-angle-right"></i>
												<p class="info clearfix">
													<span class="fl name"><span><?=$value['sName']?></span><span><?=$value['leave_day']."天假"?></span></span>
												</p>
												<p class="info clearfix zzy_info">
													<span class="fl date"><?=$value["reasons"]?></span>
												</p>
											</a>
										 <?php endforeach?>
										</div>
									
										<!-- list group end-->
								</li>
								 <?php endforeach?>
							</ul>
							
							<?php endforeach?>
							<!--星期一 end-->
				
							</div>
							<!-- panel2 end-->
							</div>
							<!-- content end-->
							</div>
							<!--inner-wap end-->
	</div>
						<!-- all end-->

<script src="js/vendor/jquery.js"></script>
<script src="js/vendor/swiper.min.js"></script>

<script src="js/foundation.min.js"></script>

<script>
		$(document).foundation();
</script>
</body>

</html>
