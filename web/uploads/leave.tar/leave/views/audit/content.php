
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="format-detection" content="telephone=no">
<title>请假条列表-详细</title>
<link rel="stylesheet" type="text/css" href="css/mydoc.css">

</head>
<body>

<div class="off-canvas-wrap" data-offcanvas>
	<div class="inner-wrap">		
		<div class="row">
			<ul class="dsq_list list_operate">
				<li>
					<a href="###" class="pic_text_iteam">
			  			<div class="pic_text_info">
			  				<div class="pic_box">
			  					<img src="img/temp/avatar.png">
			  				</div>
			  				<p class="pic_text_name">
			  					<span><?=$leave['user']['sName']?></span>
			  				</p>
			  				<p class="pic_text_msg"><span><?=$leave['user']['year']."级  ".$leave['user']['major'].$leave['user']['grade']."班"?></span></p>
			  			</div>			  			
			  		</a>
                    <?if(!$flag):?>
			  		<div class="pic_text_op">
	  					<a href="javascript:void(0)" class="ficon icon_coment" onclick="sendMqttMsg()"></a>
	  					<a href="javascript:void(0)" class="ficon icon_tel" onclick="mallCall()"></a>
	  				</div>
                    <?endif?>
				</li>
			</ul>
		</div>

		<!--请假条内容部分-->
		<div class="row">	
			<div class="dsq_content">
				<p>提交审批：<span><?=date("Y-m-d H:i", $leave["create_time"])?></span></p>
				<p>请假时间：<span><?=date("Y-m-d ", $leave["start_time"])?></span> 到 <span><?=date("Y-m-d ", $leave["end_time"])?></span></p>
				<p>请假天数：<span><?=$leave["leave_day"]?></span></p>
				<p>提交事由：<span><?=$leave["reasons"]?></span></p>	
			</div>
		</div>

		
		<div class="row">
			<div class="row-tab-thin"></div>
			<div class="dsq_content">
				<h3 class="freightTit" style="margin-left:-10px; font-weight:bold;">请假期间相关课程</h3>
				<?foreach( $unit as $u):?>
					<div class="dsq_course">
						<span class=' dsq_item'><?=date("Y-m-d ", $u["date"])?></span>
						<span class='dsq_tt dsq_item textCut'><?=$u['name']?></span>
						<span class=" dsq_item"><?=$u['setsuji']?></span>
						<span class='textCut dsq_item_head'><?=$u['course']?></span>
					</div>
				<?endforeach?>
				
				<!--a href="javascript:void(0);" id="dsq_showmore">查看更多</a-->					
			</div>

		</div>

		<!--end 请假条内容部分-->

		<!-- 审批部分 -->
		<div class="row">
            <?if($isActive === true):?>
			<div class="row-tab-thin"></div>
			<div class="conInfo">
			    <form id="result"  data-abide action="index.php?r=leave/audit/result" method="post" enctype="multipart/form-data"> 
					<div class="small-11">
                    <?if(!$flag):?>
				      <div class="row">
				        <div class="small-3 columns">
				          <label for="right-label" class="right inline">意见</label>
				        </div>
				        <div class="small-9 columns">
				          <textarea name="opinion" onpropertychange="this.style.height=this.scrollHeight + 'px'" oninput="this.style.height=this.scrollHeight + 'px'" placeholder="请输入您的意见"></textarea>
				        </div>
				      </div>
                    <?endif?>
				    </div>
					<input type="hidden" name='isEnd' value="<?=$isEnd?>">
					<input type="hidden" name='uid' value="<?=$uid?>">
					<input type="hidden" name='aid' value="<?=$aid?>">
					<input type="hidden" name='tNo' value="<?=$tNo?>">
					<input type="hidden" id="state" name='state' value="">
			    </form>
			</div>
			<!-- 下面两组按钮根据用户的身份使用其中一组 -->
			<!-- 辅导员或最高领导查看 -->
			<?if($isEnd === true):?>
	  		<div class="small-6 columns">	  			
	  			<button type="button" class="button  expand" onclick="submit_fun(2);this.disabled='disabled'" >同意</button>
	  		</div>
	  		<div class="small-6 columns">
	  			<button type="reset" class="button secondary expand" onclick="submit_fun(3);this.disabled='disabled'" >拒绝</button>
	  		</div>
			<?else:?>
	  		<!-- 同意并提交上级领导 -->
	  		<div class="small-8 columns">	  			
	  			<button type="button" class="button  expand" onclick="submit_fun(2);this.disabled='disabled'" >同意,提交上级领导审批</button>
	  		</div>
	  		
	  		<div class="small-4 columns">
	  			<button type="reset" class="button secondary expand" onclick="submit_fun(3);this.disabled='disabled'" >拒绝</button>
	  		</div>
			<?endif?>
			<?endif?>
	  	</div>
		
		<!-- end 审批部分 -->
		
		
		<!--跟踪流程-->
        <?if(!$t):?>
		<div class="row">
			<div class="row-tab-thin"></div>
			<h3 class="freightTit" style="font-weight:bold;">流程跟踪</h3>
			<ul class="freightUl">
				<?foreach($workflow as $k=>$w):?>
					<?//if($k+2 == count($workflow)):?>
					<?if(isset($w['active'])):?>
					<li class="mcurrent">
						<span class="note"></span>				
						<p><?=$w['info']?></p>
						<p class="date"><sapn><?=$w['time']?></sapn></p>
					</li>
					<?else:?>
					<li>
						<span class="note"></span>				
						<p><?=$w['info']?></p>
						<p class="date"><sapn><?=$w['time']?></p>
					</li>
					<?endif?>
				<?endforeach?>
			</ul>	
		</div>
        <?endif?>
		<!--end 跟踪流程-->
		
	</div>
</div>
<script src="js/htmlset.js"></script>
<script src="js/vendor/jquery.js"></script>
<script type="text/javascript">
	API.init();
	/*
	 * 发送消息
	 * */
	function sendMqttMsg(){
		var op_sendMqttMsg = {
			"name":"SendMqttMsg",
			"params": {
                "tid": "<?=$uidMsg?>",
			   "type": "text",
			   "content": "hello"
			}
		};
		API.send_tonative(op_sendMqttMsg);
	}
	/*
	 * 打电话
	 * */
	function mallCall(){
		var op_mallCall = {
			"name":"MallCall",
			"callback": "OnMakeCallCb",
			"params": {
                "callee": "<?=$mobile?>",
			   "calltype": "A",
			   "call": "phone"
			}
		};
		API.send_tonative(op_mallCall);
	}


	$('#dsq_showmore').click(function(){
		$('#dsq_hid').toggle();
	})
	function submit_fun(state){
   //     alert(state);
		document.getElementById("state").value = state;
		document.getElementById("result").submit();
	}

</script>

</body>
</html>
