<DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
		<title>审核列表</title>
		<link href="css/mydoc.css" rel="stylesheet" type="text/css" />
	</head>

	<body>
		<div class="off-canvas-wrap" data-offcanvas>
			<div class="inner-wrap">
				<div class="row">
					<ul class="tabs zzy_tabs" data-tab>
						<li class="tab-title small-6 small-collapse active"><a href="#panel1">未审核</a></li>
						<li class="tab-title small-6 small-collapse"><a href="#panel2">历史</a></li>
					</ul>
				</div>
				<div class="tabs-content">
					<div class="content active" id="panel1">
						<div class="list-group zzy-list">
							<!--循环的还是 list.html的结构
								a 作为循环内容
							-->

							<!--a为要循环的内容包含 图标 状态请假日期 和请假人等-->
							<?foreach($list['audit'] as $l):?>
                            <a href="<?=$l['content']?>" class="listIteam">
                                <i class="icon <?=$iconStr[$l["leave_type"]]?>"><?=$typeStr[$l["leave_type"]]?></i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span><?=$l['name']?></span><span><?=$l['leave_day']?>天假</span></span>
									<span class="fr status"><em class="zzy_daishenpi"><?=$auditStr[$l["state"]]?></em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date "><?=$l['reasons']?></span>
									<span class="fr date"><?=date("Y-m-d H:i", $l['create_time'])?></span>
								</p>
							</a>
							<?endforeach?>
						</div>
                        <?if(count($list['audit']) == 0):?>
						<div class="text-center" style="color:#999;">
                            无
						</div>
                        <?endif?>
						<!--
                    	作者：offline
                    	时间：2015-11-18
                    	描述：当没有更多请假条时，显示
                    -->
                    <!--div class="text-center" style="color:#999;">
							以上是所有请假条
					</div-->
					<!--
                    	作者：offline
                    	时间：2015-11-18
                    	描述：一直显示
                    -->
                    <!--div class="text-center zzy_more">
							<a href="list-more.html" class="text-center">
	  				                                                 查看更多
	  			            </a>
					</div-->
					</div>
					
					<!-- panel1 end-->
					<div class="content" id="panel2">
						<div class="list-group zzy-list">
							<!--循环的还是 list.html的结构
								a 作为循环内容
							-->
							<!--a为要循环的内容包含 图标 状态请假日期 和请假人等-->
							
							<?foreach($list['state'] as $l):?>
                            <a href="<?=$l['content']?>" class="listIteam">
                                <i class="icon <?=$iconStr[$l["leave_type"]]?>"><?=$typeStr[$l["leave_type"]]?></i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span><?=$l['name']?></span><span><?=$l['leave_day']?>天假</span></span>
									<span class="fr status"><em class="fc_undo"><?=$auditStr[$l["state"]]?></em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date"><?=$l['reasons']?></span>
									<span class="fr date"><?=date("Y-m-d H:i", $l['create_time'])?></span>
								</p>
							</a>
							<?endforeach?>
						</div>
                        <?if(count($list['state']) == 0):?>
						<div class="text-center" style="color:#999;">
                            无
						</div>
                        <?endif?>
						<!--div class="text-center" style="color:#999;">
							以上是所有请假条
						</div-->
					</div>
				</div>
				<!--panel2 end-->
			</div>
			<!-- content结束-->
			<div class="row-bt-button">
                <a href="index.php?r=leave/echart/index">查看统计</a>

			</div>
		</div>

		<script src="js/vendor/jquery.js"></script>
		<script src="js/vendor/swiper.min.js"></script>

		<script src="js/foundation.min.js"></script>

		<script>
			$(document).foundation();
		</script>
	</body>

</html>
