<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
		<title>选择请假单元</title>
		<link href="css/mydoc.css" rel="stylesheet" type="text/css" />
	</head>

	<body>
		<div class="off-canvas-wrap" data-offcanvas>
			<div class="inner-wrap">
				<div class="row">
					<div class="stepBox">
						<div class="step hdc_head_step1 current">1 请假信息</div>
						<div class="step hdc_head_step2 current">2 选择请假单元</div>
						<div class="step hdc_head_step3">3 完成请假</div>
					</div>

					<div class="page_tip">
						<p class="hdc_select_hint">默认所有课程已选，可自行勾选</p>
					</div>

					<form id="save" data-abide action="index.php?r=leave/student/save" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<? foreach($syllabus as $k=>$unit):?>
								<div class="row-tab">
									<span class="fc3"><?=date("Y-m-d ", $k)?></span>
								</div>
								<? foreach($unit as $uk=>$course):?>
								    <? foreach($course as $ck=>$cv):?>
									<div class="row hdc_select_row ">
										<label>
                                            <input name="checkbox[<?=$k.$uk.$cv['course_no']?>]" type="checkbox" value="<?=$k.$uk.$cv['course_no']?>" checked="checked" />
											<input type="hidden" name='unit[<?=$k.$uk.$cv['course_no']?>]' value="<?=$cv['course_no']?>">
											<input type="hidden" name='leaveTime[<?=$k.$uk.$cv['course_no']?>]' value="<?=$k?>">
											<input type="hidden" name='setsuji[<?=$k.$uk.$cv['course_no']?>]' value="<?=$cv['setsujiStr']?>">
											<span class="hdc_select_spf"><?=$cv['course']?></span>
											<span class="hdc_select_sps"><?=$cv['setsujiStr']?><span class="hdc_select_spt"><?=$cv['name']?></span></span>
										</label>
									</div>
								    <?endforeach?>
								<?endforeach?>
							<?endforeach?>
						</div>
						<!-- end form-group -->
						<div class="row-bt-button ">
							<input type="hidden" name='uid' value="<?=$uid?>">
							<input type="hidden" name='startTime' value="<?=$startTime?>">
							<input type="hidden" name='type' value="<?=$type?>">
							<input type="hidden" name='reasons' value="<?=$reasons?>">
							<input type="hidden" name='day' value="<?=$day?>">
							<input type="hidden" name='endTime' value="<?=$endTime?>">
							<!--button class="hdc_button" type="submit" style="line-height: 0;">提交请假条</button-->
                            <div class="small-5 columns">
                                <input id='infoButton' type="button" class="button secondary expand" onclick="infoFun();"; value="上一步">
                            </div>
                            <div class="small-7 columns">
                                <input id='submitButton' type="button" class="button expand" onclick="submitFun();" value="提交请假条">
                            </div>
						</div>
					</form>
					<!-- end form -->
					<form id="info" data-abide action="index.php?r=leave/student/info" method="post" enctype="multipart/form-data">
						<input type="hidden" name='uid' value="<?=$uid?>">
						<input type="hidden" name='startTime' value="<?=$startTime?>">
						<input type="hidden" name='type' value="<?=$type?>">
						<input type="hidden" name='reasons' value="<?=$reasons?>">
						<input type="hidden" name='day' value="<?=$day?>">
						<input type="hidden" name='endTime' value="<?=$endTime?>">
					</form>

				</div>
				<!-- end row -->

			</div>

		</div>

		</div>

	</body>
    <script type="text/javascript">
        function submitFun(){
            document.getElementById("infoButton").disabled="none";
            document.getElementById("submitButton").disabled="none";
            document.getElementById("save").submit();
        }
        function infoFun(){
            document.getElementById("infoButton").disabled="disabled";
            document.getElementById("submitButton").disabled="disabled";
            document.getElementById("info").submit();
        }
    </script>
</html>

