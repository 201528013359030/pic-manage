<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
		<title>完成请假</title>
		<link href="css/mydoc.css" rel="stylesheet" type="text/css" />
	</head>

	<body>
		<div class="off-canvas-wrap" data-offcanvas>
			<div class="inner-wrap">

				<div class="stepBox">
					<div class="step hdc_head_step1 current">1 请假信息</div>
					<div class="step hdc_head_step2 current">2 选择请假单元</div>
					<div class="step hdc_head_step3  current">3 完成请假</div>
				</div>

				<div class="hdc_submit">

					<div class="hdc_submit_success">

						<div>
							<img src="img/icon_success.png" /> &nbsp;
							<span>提交成功</span>
						</div>

						<p>请假条正在审批中...</p>

					</div>

					<div>
                        <a class="hdc_success_color" href="<?=$infoUrl?>">查看请假条详细>></a>
                        <br /><br />
						<div class="row">
							<div class="small-2 columns">
								&nbsp;
							</div>
							<div class="small-8 columns">
                                <a href="<?=$listUrl?>" class="button expand">
	  				                                返回请假条列表
	  			                </a>
							</div>
							<div class="small-2 columns">
								&nbsp;
							</div>
						</div>

					</div>

				</div>

			</div>

		</div>

	</body>

</html>
