<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
		<title>请假信息</title>
		<link href="css/mydoc.css" rel="stylesheet" type="text/css" />
	</head>

	<body>

		<div class="off-canvas-wrap" data-offcanvas>
			<div class="inner-wrap">

				<div class="row">
					<form data-abide action="index.php?r=leave/student/create" method="post" enctype="multipart/form-data">

						<!--表单主体-->
						<div class="form-group">
							<div class="stepBox">
								<div class="step hdc_head_step1 current">1 请假信息</div>
								<div class="step hdc_head_step2">2 选择请假单元</div>
								<div class="step hdc_head_step3">3 完成请假</div>
							</div>

							<div class="row hdc_submit_type">
								<div class="small-3 columns">
									<label for="right-label" class="center inline">类型</label>
								</div>
								<div class="small-9 columns">
									<select name="type" data-invalid aria-invalid="true" required>
										<?foreach($types as $k=>$v):?>
											<option value="<?=$k?>" <?= $type==$k?' selected = "selected" ':'';?>><?=$v?></option>
										<?endforeach?>
									</select>
									<small class="error">请正确选择类型</small>
								</div>
							</div>

							<div class="row">
								<div class="small-3 columns">
									<label for="right-label" class="center inline">事由</label>
								</div>
								<div class="small-9 columns">
                                    <textarea id="reason" name="reasons" maxlength="141" onpropertychange="this.style.height=this.scrollHeight + 'px'" oninput="this.style.height=this.scrollHeight + 'px'" placeholder="请输入请假原因" required data-abide-validator="checkReason"><?=$reasons?></textarea>
									<small class="error">请输入请假原因最多140字</small>
								</div>
							</div>

							<div class="row">
								<div class="small-3 columns">
									<label for="right-label" class="center inline">天数</label>
								</div>
								<div class="small-9 columns">

                                    <input type="text" size="5" name="day" value="<?=$day?>" placeholder="请输入请假天数" pattern="number" required>
									<small class="error">请假天数不能为空，且为数字</small>
								</div>
							</div>

							<div class="row">
								<div class="small-3 columns">
									<label for="right-label" class="center inline">开始</label>
								</div>
								<div class="small-9 columns">
                                    <input id="starTime" class="datesel" name="startTime" type="text" value="<?=$startTime?date("Y-m-d",$startTime):""?>"  placeholder="请选择" required />
									<small class="error">请选择开始时间</small>
								</div>
							</div>

							<div class="row">
								<div class="small-3 columns">
									<label for="right-label" class="center inline">结束</label>
								</div>
								<div class="small-9 columns">
                                    <input class="datesel" name="endTime" type="text" value="<?=$endTime?date("Y-m-d",$endTime):""?>" placeholder="请选择" required data-greatthan="starTime" data-abide-validator="greatThan" />
									<small class="error">结束时间不能小于开始时间</small>
								</div>
							</div>

							<div class="row-bt-button">
                                <input type="hidden" name='uid' value="<?=$uid?>">
								<button class="hdc_button" type="submit">下一步</button>
							</div>
						</div>
						<!-- end form-group -->

					</form>

				</div>
				<!-- end row -->

			</div>
		</div>

		<script src="js/vendor/jquery.js"></script>
		<script src="js/foundation.min.js"></script>

		<!--时间控件部分-->
		<link href="js/vendor/mobiscroll.mo.min.css" rel="stylesheet" type="text/css" />
		<script src="js/vendor/mobiscroll.custom.min.js" type="text/javascript"></script>
		<script type="text/javascript">
			$(document).foundation({
				abide: {
					patterns: {
						number: /^[+]?[1-9]\d*$/,
					},
					validators: {
						greatThan: function(el, required, parent) {
							var from = document.getElementById(el.getAttribute(this.add_namespace('data-greatthan'))).value,
								to = el.value,
								valid = (from < to);
							return valid;
						},
						checkReason: function(el, required, parent) {
							var num = document.getElementById('reason').value.length,
								valid = (num <= 140 && num != 0);
							return valid;
						},
					}
				}
			});
			$(function() {
				//初始化时间控件 使用的是 mobiscroll
				$(".datesel").mobiscroll().date();
				var _mode = '';
				if (/(Android)/i.test(navigator.userAgent)) {
					_mode = 'clickpick';
				} else {
					_mode = 'scroller';
				}
				var currYear = (new Date()).getFullYear();
				//初始化日期控件
				var opt = {
					preset: 'date', //日期，可选：date\datetime\time\tree_list\image_text\select
					theme: 'androids', //皮肤样式，可选：default\android\androids\android-ics light\android-ics\ios\jqm\sense-ui\wp light\wp有些样式不可用
					display: 'modal', //显示方式 ，可选：modal\inline\bubble\top\bottom
					mode: _mode, //日期选择模式，可选：scroller\clickpick\mixed
					lang: 'zh',
					dateFormat: 'yyyy-mm-dd', // 日期格式
					setText: '确定', //确认按钮名称
					cancelText: '取消', //取消按钮名籍我
					dateOrder: 'yyyymmdd', //面板中日期排列格式
					dayText: '日',
					monthText: '月',
					yearText: '年', //面板中年月日文字
					showNow: false,
					nowText: "今",
					startYear: currYear, //开始年份  
					endYear: currYear + 100, //结束年份  
					//endYear:2099 //结束年份
					timeFormat: 'HH:ii:ss',
					timeWheels: 'HHiiss'
				};
				$(".datesel").mobiscroll(opt);
			});
		</script>

	</body>

</html>
