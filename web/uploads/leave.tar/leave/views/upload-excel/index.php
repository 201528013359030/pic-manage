<?php
use yii\helpers\Html;
use yii\jui\DatePicker;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
$this->title = '导入课程信息';
// $this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <!-- <p>
        This is the Import page. 
    </p>

    <code><?//= __FILE__ ?></code> -->
</div>
<?//= DatePicker::widget(['name'=>'data'])?>
<?php 
$form = ActiveForm::begin(['id' => 'login-form','enableAjaxValidation' => false,  'options' =>  ['enctype' => 'multipart/form-data']]); 
if ($model->hasErrors()) { 
//it is necessary to see all the errors for all the files.  
  echo '<pre>';  
    print_r($model->getErrors());   
  echo '</pre>';}
?>

	<?= $form->field($model, 'file[]')->fileInput(['multiple'=>'']);?>


    <div class="form-group">
        <?= Html::submitButton('上传',['class' => 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>
