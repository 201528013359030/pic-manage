<?php
use yii\helpers\Html;
use yii\jui\DatePicker;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
$this->title = '导入课程信息';
// $this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <!-- <p>
        This is the Import page. 
    </p>

    <code><?//= __FILE__ ?></code> -->
</div>
<?//= DatePicker::widget(['name'=>'data'])?>
<?php $form = ActiveForm::begin(['id' => 'login-form','enableAjaxValidation' => false,  'options' =>  ['enctype' => 'multipart/form-data']]); ?>

	<?= $form->field($model, 'file')->fileInput()->label('') ?>


    <div class="form-group">
        <?= Html::submitButton('上传',['class' => 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>
