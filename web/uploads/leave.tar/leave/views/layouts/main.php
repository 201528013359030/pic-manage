<?php
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\helpers\Url;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
// Yii::$app->params['urlSubflag'] = 'heh';
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" >
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="renderer" content="webkit">

<?php $this->head() ?>
</head>
<title>详细信息</title>
<style >

	.nav-pills > li > a {
	color: #222; 
	border-radius: 0px;
	padding: 7px 0px;
	padding-left: 65px;
	font-family: "Helvetica Neue","Hiragino Sans GB","Microsoft YaHei","\9ED1\4F53",Arial,sans-serif;
	}
	.nav-pills > li.active > a,
	.nav-pills > li.active > a:hover,
	.nav-pills > li.active > a:focus {
	background-color: #3076C2;
	}
	.nav-font-1{
		font-size: 15px;
		font-weight: bold;
		color: #9C9C9C;
		vertical-align: middle;
	}
	.nav-stacked > li + li{
		margin-top:0px;
	}
</style>
<body>

<?php $this->beginBody() ?>
<div id="wrap"  class="wrap"  style="margin: 0 auto;">	
	<div class="col-md-10">
		<?php echo $content; ?>
	</div>
</div>	
<?php $this->endBody() ?>
</body>

<script>
$(function(){
	//var subflag = "<?//=(Yii::$app->request->get('subflag')?Yii::$app->request->get('subflag'):'0101') ?>";
	//$("#"+subflag).attr("class","active");
});
	
</script>
</html>
<?php $this->endPage() ?>
