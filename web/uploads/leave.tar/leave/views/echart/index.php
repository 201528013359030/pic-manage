<html>

<head>
<meta charset="utf-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="format-detection" content="telephone=no">
<title>统计列表</title>
<link href="css/mydoc.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="list-group zzy-list">
        <a href="index.php?r=leave/echart/year" class="zzy_a listIteam ">
            <img class="zzy_img" src="img/icon_grade.png" /><span class="zzy_span">年级</span>
            <br/><span class="fc6 zzy_foot">按年级统计学生请假</span>
        </a>
        <a href="index.php?r=leave/echart/institute" class="zzy_a listIteam ">
            <img class="zzy_img" src="img/icon_univercity.png" /><span class="zzy_span">院系</span>
            <br/><span class="fc6 zzy_foot">按院系统计学生请假</span>
        </a>
        <a href="index.php?r=leave/echart/major" class="zzy_a listIteam ">
            <img class="zzy_img" src="img/icon_major.png" /><span class="zzy_span">专业</span>
            <br/><span class="fc6 zzy_foot">按院专业计学生请假</span>
        </a>
        <a href="index.php?r=leave/echart/search" class="zzy_a listIteam">
            <img class="zzy_img" src="img/icon_class.png" /><span class="zzy_span">班级</span>
            <br/><span class="fc6 zzy_foot">按院班级计学生请假</span>
        </a>
    </div>
</body>

</html>
