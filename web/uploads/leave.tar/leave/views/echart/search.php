<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
		<title>查询统计</title>
		<link href="css/mydoc.css" rel="stylesheet" type="text/css" />
	</head>

	<body>

		<div class="off-canvas-wrap" data-offcanvas>
			<div class="inner-wrap">

				<div class="row">
					
					<div class="page_title">按条件查询</div>

					<form id="instituteSubmit" data-abide method="POST" enctype="multipart/form-data" action="index.php?r=leave/echart/search">

						<!--表单主体-->
						<div class="form-group">
							
							<div class="row">
						        <div class="small-3 columns">
						          <label for="right-label" class="center inline">年级</label>
						        </div>
						        <div class="small-9 columns">
						            <select id='year' name='year'>
							          	<!--option value="">请选择</option-->
                                        <?foreach($year as $y ):?>
                                        <option value="<?=$y?>" <?=$sYear==$y?"selected = 'selected'":""?>><?=$y?>级</option>
                                        <?endforeach?>
							        </select>
							        <small class="error">请选择年级</small>
						        </div>
						    </div>
						    <div class="row">
						        <div class="small-3 columns">
						          <label for="right-label" class="center inline">院系</label>
						        </div>
						        <div class="small-9 columns">
						            <select id="institute" name='institute' onchange="selectinstitute();">
							          	<option value="">请选择</option>
                                        <?foreach($institute as $i ):?>
                                        <option value="<?=$i?>" <?=$sInstitute==$i?"selected = 'selected'":""?>><?=$i?></option>
                                        <?endforeach?>
							        </select>
							        <small class="error">请选择院系</small>
						        </div>
						    </div>
						    <div class="row">
						        <div class="small-3 columns">
						          <label for="right-label" class="center inline">专业</label>
						        </div>
						        <div class="small-9 columns">
						            <select id='major' name='major'>
							          	<option value="">请选择</option>
                                        <?foreach($major as $m ):?>
                                            <option value="<?=$m?>"><?=$m?></option>
                                        <?endforeach?>
							        </select>
							        <small class="error">请选择专业</small>
						        </div>
						    </div>
						    
							<div class="row-bt-button">

								<button class="hdc_button" type="button" onclick="search();">统计</button>
							</div>

						</div>
						<!-- end form-group -->
						
					</form>
					<form id="search" data-abide method="POST" enctype="multipart/form-data" action="index.php?r=leave/echart/class">
                        <input id="syear" type="hidden" name='year' value=""> 
                        <input id="sinstitute" type="hidden" name='institute' value=""> 
                        <input id="smajor" type="hidden" name='major' value=""> 
					</form>

				</div>
				<!-- end row -->

			</div>
		</div>

		<script src="js/vendor/jquery.js"></script>
		<script src="js/foundation.min.js"></script>

		<script type="text/javascript">
			$(document).foundation();
            function selectinstitute(){
                document.getElementById("instituteSubmit").submit();
            }
            function search(){
                document.getElementById("smajor").value = document.getElementById("major").value;
                document.getElementById("sinstitute").value = document.getElementById("institute").value;
                document.getElementById("syear").value = document.getElementById("year").value;
       //         return;
                document.getElementById("search").submit();
            }
			
		</script>

	</body>

</html>
