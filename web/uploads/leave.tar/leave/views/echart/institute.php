
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="format-detection" content="telephone=no">
<title>请假统计</title>
<link rel="stylesheet" type="text/css" href="css/mydoc.css">
<link rel="stylesheet" type="text/css" href="css/dsq.css">
</head>
<body>
<div class="off-canvas-wrap" data-offcanvas>
    <div class="inner-wrap">
        <h3 class="dsq_echart0_h3"><?=$title?></h3>
        <!--p class="dsq_echart0_p">统计时间：<span>2015-01-12</span>到<span>2015-11-16</span></p-->
        <p class="dsq_echart0_p"><?=$term?></p>
        <!-- 为ECharts准备一个具备大小（宽高）的Dom -->
        <div id="dsq_main"></div>
        <!--p class="dsq_echart0_p">查看各院系请假人数</p-->
    </div>
</div>
    <!-- ECharts单文件引入 -->
<script src="js/dist/echarts.js"></script>
<script type="text/javascript">
    
var n = <?=count($echart)?>; //有多少条数据
if(n<5){
    n=5;
}
document.getElementById("dsq_main").style.height = n*44 + 'px';
setTimeout("showcharts()",800);
function showcharts(){
    
    	var win_w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    	// 变量申明，通过这个数组变量改变图标的内容
        var legend_data=['请假'];
        var yAxis_data = [];
        var number_data = [];
        <?foreach($echart as $k=>$l):?>
        yAxis_data[<?=$k?>] = "<?=$l['name']?>";
        number_data[<?=$k?>] = "<?=$l['count']?>";
        <?endforeach?>
    
        // 路径配置
        require.config({
            paths: {
                echarts: 'js/dist'
            }
        });
        
        // 使用
        require(
            [
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/bar' // 使用柱状图就加载bar模块，按需加载
            ],
            function (ec,theme) {
                // 基于准备好的dom，初始化echarts图表
                var myChart = ec.init(document.getElementById('dsq_main'),theme);
                                
                var option = {
                	title : {
                		show:false
                	},
                    tooltip : {
                		show:false,
                        trigger: 'axis',
                        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                        },
                        //backgroundColor : 'rgba(0,0,0,0.3)',
                        position:function(p){
			        		return [win_w-100,20];
			        	},
                     
                    },
			    	calculable : false,
                    
                    legend: {
                    	show : false,
                        data:legend_data
                    },

                    yAxis : [
                        {
                            type : 'category',
                            data : yAxis_data
                        }
                    ],
                    xAxis : [
                        {
                            type : 'value',
                            boundaryGap: [0, 1]
                        }
                    ],
                    series : [
                        {
                            "name":"请假(人)",
                            "type":"bar",
                            stack: '总量',
                            itemStyle : { normal: {color:'#4292E4',barBorderRadius:0,
                            label : {show: true, position: 'insideRight'}}
                            },
                            "data":number_data
                        }
                    ]
                };
                
        		// 如果需要再次使用ECharts的图表实例，建议你还是保存init返回的图表实例
				var myChart = require('echarts').init(document.getElementById("dsq_main"),theme);
                // 为echarts对象加载数据 
                myChart.setOption(option); 
            }
        );
}
    </script>
</body>

