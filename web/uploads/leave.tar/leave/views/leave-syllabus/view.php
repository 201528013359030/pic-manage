<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\LeaveSyllabus */

/* $this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Leave Syllabi', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title; */
?>
<div class="leave-syllabus-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('更新', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('删除', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'campus',
            'term',
            'institute',
            'major',
            'grade',
            'class',
            'course',
            'course_no',
            'credit',
            'hours',
            'teach_hours',
            'experiment_hours',
            'evaluation',
            'course_type',
            'course_classes',
            'teacher',
            'class_code',
            'course_number',
            'week',
            'setsuji',
        ],
    ]) ?>

</div>
