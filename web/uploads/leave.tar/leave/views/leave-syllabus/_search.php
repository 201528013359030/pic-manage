<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\LeaveSyllabusSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="leave-syllabus-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'campus') ?>

    <?= $form->field($model, 'term') ?>

    <?= $form->field($model, 'institute') ?>

    <?= $form->field($model, 'major') ?>

    <?php // echo $form->field($model, 'grade') ?>

    <?php // echo $form->field($model, 'class') ?>

    <?php // echo $form->field($model, 'course') ?>

    <?php // echo $form->field($model, 'course_no') ?>

    <?php // echo $form->field($model, 'credit') ?>

    <?php // echo $form->field($model, 'hours') ?>

    <?php // echo $form->field($model, 'teach_hours') ?>

    <?php // echo $form->field($model, 'experiment_hours') ?>

    <?php // echo $form->field($model, 'evaluation') ?>

    <?php // echo $form->field($model, 'course_type') ?>

    <?php // echo $form->field($model, 'course_classes') ?>

    <?php // echo $form->field($model, 'teacher') ?>

    <?php // echo $form->field($model, 'class_code') ?>

    <?php // echo $form->field($model, 'course_number') ?>

    <?php // echo $form->field($model, 'week') ?>

    <?php // echo $form->field($model, 'setsuji') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
