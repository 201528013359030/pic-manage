<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\LeaveSyllabusSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '课程信息';
// $this->params['breadcrumbs'][] = $this->title;
?>
<div class="leave-syllabus-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('添加', ['create'], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('导入', ['import'], ['class' => 'btn btn-primary']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

//             'id',
//             'campus',
//             'term',
//     		['attribute' => 'institute','label'=>'学院','contentOptions' => ['width' => '10%']],
            'institute',
            'major',
            'grade',
            'class',
            'course',
//             'course_no',
            'credit',
            'hours',
//             'teach_hours',
//             'experiment_hours',
            'evaluation',
            'course_type',
            'course_classes',
            'teacher',
//             'class_code',
//             'course_number',
            'week',
            'setsuji',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>
