<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\LeaveSyllabus */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="leave-syllabus-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'campus')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'term')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'institute')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'major')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'grade')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'class')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'course')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'course_no')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'credit')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'hours')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'teach_hours')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'experiment_hours')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'evaluation')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'course_type')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'course_classes')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'teacher')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'class_code')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'course_number')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'week')->textInput(['maxlength' => 128]) ?>

    <?= $form->field($model, 'setsuji')->textInput(['maxlength' => 128]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? '添加' : '更新', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
