<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
		<title>我的请假条</title>
		<link href="css/mydoc.css" rel="stylesheet" type="text/css" />
	</head>

	<body>
		<div class="off-canvas-wrap" data-offcanvas>
			<div class="inner-wrap">
				<div class="row">

					<ul class="tabs zzy_tabs" data-tab>
						<li class="tab-title small-6 small-collapse active"><a href="#panel1">待审批</a></li>
						<li class="tab-title small-6 small-collapse"><a href="#panel2">历史</a></li>

					</ul>
				</div>
				<div class="tabs-content">
					<!--tab1的内容区域-->
					<div class="content active" id="panel1">
						<div class="list-group zzy-list">
							<!--循环的还是 list.html的结构
								a 作为循环内容
							-->

							<!--a为要循环的内容包含 图标 状态请假日期 和请假人等-->
							<?foreach( $activeList as $leave):?>
							<a href="index.php?r=leave/leave-history/detail&leaveId=<?=$leave["id"] ?>&uid=<?=$uid ?>" class="listIteam">
								<i class="icon <?=$typeIcon[$leave["leave_type"]] ?>"><?=$typeStr[$leave["leave_type"]] ?></i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span><?=$leave["leave_day"] ?>天假</span></span>
									<span class="fr status"><em class="zzy_daishenpi"><?=$auditStr[$leave["state"]] ?></em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date"><?=$leave["reasons"] ?></span>
									<span class="fr date"><?=date('Y-m-d H:i',$leave["create_time"]) ?></span>
								</p>
							</a>
							<?endforeach?>
							<!-- <a href="javascript:void(0);" class="listIteam">
								<i class="icon ic_ill">病</i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span>2天假</span></span>
									<span class="fr status"><em class="zzy_daishenpi">待审批</em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date">发烧了，去医院...</span>
									<span class="fr date">今天 10:00</span>
								</p>
							</a> -->
						</div>
					</div>
					<!-- panel1结束-->
					<div class="content" id="panel2">
						<div class="list-group zzy-list">
							<!--循环的还是 list.html的结构
								a 作为循环内容
							-->
							<!--a为要循环的内容包含 图标 状态请假日期 和请假人等-->
							<?foreach( $historyList as $leave):?>
							<a href="index.php?r=leave/leave-history/detail&leaveId=<?=$leave["id"] ?>&uid=<?=$uid ?>" class="listIteam">	
								<i class="icon <?=$typeIcon[$leave["leave_type"]] ?>"><?=$typeStr[$leave["leave_type"]] ?></i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span><?=$leave["leave_day"] ?>天假</span></span>
									<span class="fr status"><em class="fc_undo"><?=$auditStr[$leave["state"]] ?></em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date"><?=$leave["reasons"] ?></span>
									<span class="fr date"><?=date('Y-m-d H:i',$leave["create_time"]) ?></span>
								</p>
							</a>
							<?endforeach?>
							<!-- <a href="javascript:void(0);" class="listIteam">
								<i class="icon ic_ill">病</i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span>2天假</span></span>
									<span class="fr status"><em class="fc_undo">同意</em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date">发烧了，去医院...</span>
									<span class="fr date">2015-9-11 10:00</span>
								</p>
							</a>
							<a href="javascript:void(0);" class="listIteam">
								<i class="icon ic_shi">事</i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span>2天假</span></span>
									<span class="fr status"><em class="fc_undo">拒绝</em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date">展示请假事由....</span>
									<span class="fr date">今天 16:00</span>
								</p>
							</a>
							<a href="javascript:void(0);" class="listIteam">
								<i class="icon ic_marry">婚</i>
								<i class="ficon icon-angle-right"></i>
								<p class="info clearfix">
									<span class="fl name"><span>1天假</span></span>
									<span class="fr status"><em class="fc_undo">同意</em></span>
								</p>
								<p class="info clearfix zzy_info">
									<span class="fl date">展示请假事由....</span>
									<span class="fr date">2015-09-11 16:00</span>
								</p>
							</a> -->

						</div>
						<!-- <div class="text-center zzy_more">
							<a href="list-more.html" class="text-center">
	  				                                                 查看更多
	  			            </a>
						</div> -->
					</div>
				</div>
				<!--panel2 end-->
			</div>
			<!-- content结束-->
			<div class="row-bt-button">
				<a href="index.php?r=leave/student/info&uid=<?=$uid ?>">创建请假条</a>
			</div>
		</div>
		</div>
		<script src="js/vendor/jquery.js"></script>
		<script src="js/vendor/swiper.min.js"></script>

		<script src="js/foundation.min.js"></script>

		<script>
			$(document).foundation();
		</script>
	</body>

</html>
