
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta id="viewport" name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="format-detection" content="telephone=no">
<title>请假条列表-详细</title>
<link rel="stylesheet" type="text/css" href="css/mydoc.css">

</head>
<body>

<div class="off-canvas-wrap" data-offcanvas>
	<div class="inner-wrap">		
		
		<!--请假条内容部分-->
		<div class="row">	
			<div class="dsq_content">
				<p>提交审批：<span><?=date('Y-m-d H:i',$leaveInfo["create_time"]) ?></span></p>
				<p>请假时间：<span><?=date('Y-m-d',$leaveInfo["start_time"]) ?></span> 到 <span><?=date('Y-m-d',$leaveInfo["end_time"]) ?></span></p>
				<p>请假天数：<span><?=$leaveInfo["leave_day"] ?></span></p>
				<p>提交事由：<span><?=$leaveInfo["reasons"] ?></span></p>	
			</div>
		</div>

		
		<div class="row">
			<div class="row-tab-thin"></div>
			<div class="dsq_content">
				<h3 class="freightTit" style="margin-left:-10px; font-weight:bold;">请假期间相关课程</h3>
				<?foreach( $unit as $u):?>
					<div class="dsq_course">
						<span class=' dsq_item'><?=date("Y-m-d ", $u["date"])?></span>
						<span class='dsq_tt dsq_item textCut'><?=$u['name']?></span>
						<span class=" dsq_item"><?=$u['setsuji']?></span>
						<span class='textCut dsq_item_head'><?=$u['course']?></span>
					</div>
				<?endforeach?>
				<!-- <div class="dsq_course">
					<span class=' dsq_item'>2015-11-09</span>
					<span class='dsq_tt dsq_item textCut'>张冬雪</span>
					<span class=" dsq_item">1-2节</span>
					<span class='textCut dsq_item_head'>创业基础</span>
				</div>
				<div class="dsq_course">
					<span class=' dsq_item'>2015-11-10</span>
					<span class='dsq_tt dsq_item textCut'>王敏</span>
					<span class=" dsq_item">3-4节</span>
					<span class='textCut dsq_item_head'>博雅课堂-开讲啦</span>
				</div>
				<div id="dsq_hid" style="display: none;">
					<div class="dsq_course">
						<span class='dsq_item'>2015-11-10</span>
						<span class='dsq_tt dsq_item textCut'>王敏</span>
						<span class=" dsq_item">3-4节</span>
						<span class='textCut dsq_item_head'>博雅课堂-开讲啦</span>
					</div>
					<div class="dsq_course">
						<span class='dsq_item'>2015-11-10</span>
						<span class='dsq_tt dsq_item textCut'>王敏</span>
						<span class=" dsq_item">3-4节</span>
						<span class='textCut dsq_item_head'>博雅课堂-开讲啦</span>
					</div>
				</div> -->
				
				<!-- <a href="javascript:void(0);" id="dsq_showmore">查看更多</a>	 -->				
			</div>

		</div>


		
		<!--end 请假条内容部分-->
		<?if($ishistory == 0){ ?>			
		<div class="row">
		<form id="result1"  data-abide action="index.php?r=leave/leave-history/send-notice" method="post"> 
			<div class="row-tab-thin"></div>
			<p class="dsq_tip">如果<?=$task_name ?>长时间没有审批，可以提醒<?=$task_name ?>审批</p>
			<div class="small-6 columns">	
	  			<button type="submit" class="button  expand">提醒审批</button>
	  		</div>
	  		<input type="hidden" name='uid' value="<?=$uid?>">
			<input type="hidden" name='leaveId' value="<?=$leaveId?>">
			<input type="hidden" name='tUid' value="<?=$tUid ?>">
	  	</form>
	  	<form id="result2"  data-abide action="index.php?r=leave/leave-history/cancel" method="post"> 
		
	  		<?if($isInstructor == 1){ ?>
	  		<div class="small-6 columns">
	  			<button type="submit" class="button secondary expand">取消请假</button>
	  		</div>
	  		<?} ?>
	  		<input type="hidden" name='uid' value="<?=$uid?>">
			<input type="hidden" name='leaveId' value="<?=$leaveId?>">
		</form>
	  	</div>
	  	<?} ?>
	  	
		
		
		
		
		<!--跟踪流程-->
		<div class="row">
			<div class="row-tab-thin"></div>
			<h3 class="freightTit" style="font-weight:bold;">流程跟踪</h3>
			<ul class="freightUl">
				<?if($ishistory == 0){ ?>				
					<li class="mcurrent">
						<span class="note"></span>				
						<p><?=$currentTask['info']?></p>
						<p class="date"><sapn><?=$currentTask['time']?></sapn></p>
					</li>
				<?} ?>
				<?foreach($workflow as $k=>$w):?>					
					<li>
						<span class="note"></span>				
						<p><?=$w['info']?></p>
						<p class="date"><sapn><?=$w['time']?></p>
					</li>
				<?endforeach?>		
				<!-- <li class="mcurrent">
					<span class="note"></span>				
					<p>辅导员&nbsp;已同意&nbsp;<span>好好治疗，找同学补课</span></p>
					<p class="date"><sapn>2015-11-08 16:00</sapn></p>
				</li>
				<li>
					<span class="note"></span>				
					<p>创建请假条</p>
					<p class="date"><sapn>2015-11-08 16:00</sapn></p>
				</li> -->
				
			</ul>	
			
		</div>
		<!--end 跟踪流程-->
		
		
		
	</div>
</div>
<script src="js/htmlset.js"></script>
<script src="js/vendor/jquery.js"></script>
<script type="text/javascript">
	API.init();
	/*
	 * 发送消息
	 * */
	function sendMqttMsg(){
		var op_sendMqttMsg = {
			"name":"SendMqttMsg",
			"params": {
			   //"tid": "97364@83273",
			   "tid": <?=$tUid ?>
			   "type": "text",
			   "content": "hellow world"
			}
		};
		API.send_tonative(op_sendMqttMsg);
	}
	$('#dsq_showmore').click(function(){
		$('#dsq_hid').toggle();
	})
</script>
</body>
</html>
