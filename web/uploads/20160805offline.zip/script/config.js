var PAGE_URL   = window.location.href,
	API_KEY    = "36116967d1ab95321b89df8223929b14207b72b1",
	SERVER_IP  = get_param("serverIp"),
	USER_AGENT = getClientType(),
	NATIVE_UID = get_param("uid"),
	NATIVE_EGUID = get_param("eguid"),
	NATIVE_GID = get_param("gid"),
	NATIVE_AUTH_TOKEN = get_param("auth_token"),
	monthNames = [ "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" ],
	dayNames= ["周日","周一","周二","周三","周四","周五","周六"];


console.log("USER_AGENT:"+USER_AGENT);
sessionStorage.setItem("API_KEY",API_KEY);
sessionStorage.setItem("USER_AGENT",USER_AGENT);
sessionStorage.setItem("SERVER_IP",SERVER_IP);	
sessionStorage.setItem("NATIVE_UID",NATIVE_UID);
sessionStorage.setItem("NATIVE_GID",NATIVE_GID);
sessionStorage.setItem("NATIVE_EGUID",NATIVE_EGUID);
sessionStorage.setItem("NATIVE_AUTH_TOKEN",NATIVE_AUTH_TOKEN);

/**
 * @param OnSGetAppVersionCb datas
 * 获取版本号
 */
function OnDidFinishLoadCb(datas){
	NativeInteractive.getAppVersion();
}
if(USER_AGENT!="IOS"){
	NativeInteractive.getAppVersion();
}

function OnSGetAppVersionCb(datas){
	var params = datas.result.params,
		systemName = params.systemName,
		version = params.version,
		versionCode = "";
	if(systemName=="AN"){
		versionCode = params.versionCode;
		sessionStorage.setItem("VERSION_CODE",versionCode);
	}
	
	sessionStorage.setItem("VERSION",version);
	//sessionStorage.setItem("VERSION_CODE",versionCode);
}

/*
 * @ 函数名    ：get_param(name)
 * 参数说明：name 为 ？ 后面的参数名
 * 
 */
function get_url_param(){
	var url = location.search; //获取url中"?"符后的字串
	var theRequest = new Object();
	if (url.indexOf("?") != -1) {
	   var str = url.substr(1);
	   strs = str.split("&");
	   for(var i = 0; i < strs.length; i ++) {
	      theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
		   }
	}

	return theRequest;
}
function get_param(name){
	var theRequest = get_url_param();
	return theRequest[name];
}

function parseURL(url) { 
	var a = document.createElement('a'); 
	a.href = url; 
	return { 
		source: url, 
		protocol: a.protocol.replace(':',''), 
		host: a.hostname, 
		port: a.port, 
		query: a.search, 
		params: (function(){ 
			var ret = {}, 
			seg = a.search.replace(/^\?/,'').split('&'), 
			len = seg.length, i = 0, s; 
			for (;i<len;i++) { 
			if (!seg[i]) { continue; } 
			s = seg[i].split('='); 
			ret[s[0]] = s[1]; 
			} 
			return ret; 
		})(), 
		file: (a.pathname.match(/\/([^\/?#]+)$/i) || [,''])[1], 
		hash: a.hash.replace('#',''), 
		path: a.pathname.replace(/^([^\/])/,'/$1'), 
		relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [,''])[1], 
		segments: a.pathname.replace(/^\//,'').split('/') 
	}; 
}

function getClientType(){
	
	var user_agent = "PC";
	if( /(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) ){
		user_agent = "IOS";
	};
	if( /(Android)/i.test(navigator.userAgent) ){
		user_agent = "AN";
	}
	return user_agent;
}


