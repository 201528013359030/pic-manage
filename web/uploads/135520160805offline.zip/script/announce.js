var notfound = {};
notfound.partial = "../announce/temp/404.html";
notfound.init = function(){
    console.log('网址不存在');
}
var noweb = {};
noweb.partial = "../announce/temp/noweb.html";
noweb.init = function(){
	$("#J_backHome").on("click",function(){
		window.location.replace("#home");
	});
    console.log('网址不存在');
}
var homeTimer="";
var home= {};
home.partial = "../announce/temp/home.html";
home.init = function(){
	miniSPA.render("home");
	$("body").css("background-color","#fff");
	$.hideLoading();
	homeTimer = setTimeout(function(){
		
		$(".homeLoading").css("display","none");
		$("#page-ptr-navbar").css("display","block");
		
		var nodata = dataEmpty("nodata","请求超时","很抱歉，请检查您的网络稍后再试");
		$("#J_innerContent").html( nodata );
	},3000);
	
	NativeInteractive.getNetStatus();
	
}
function OnAppCacheFetchCb(datas){
	
	var status = datas.result.status,
		params = datas.result.params;
	//这里做一个演示，把数据转成字符串在页面弹出
	if(params.data){
		var datastr = params.data;
		var data = utf8to16(base64decode(datastr));
		setAnnList("","0",{"isonLine":false,"data":JSON.parse(data)});
	}else{
		window.location.href('#noweb');
	}
}
function OnGetNetStatusCb(datas){
	clearTimeout(homeTimer);
	
	$(".homeLoading").css("display","none");
	$("#page-ptr-navbar").css("display","block");
		
	var status = datas.result.status,
		params = datas.result.params;
	
	if(params.reachability=="Reachable"){
		setAnnList("","0",{"isonLine":true});
		$(".weui-pull-to-refresh-layer").css("display","block");
		if(cansave()||isgroupOwner()){
			$("#page-ptr-navbar").append('<div class="endButton"><a href="#upload" id="sendAnn">发布公告</a></div>');
		}
		$("#annList").on("click",".contentIteam",function(){
			var obj = this;
			if($(obj).find(".ui-badge").length>0){
				$(obj).find(".ui-badge").remove();
			}
		});
		//此处开始为下拉刷新与上拉加载的代码	
		if($("#page-ptr-navbar")[0]) {
			
			$("#tab1").pullToRefresh().on("pull-to-refresh", function() {
			    var self = this;
			    
			    setTimeout(function() {
			      	window.location.reload();
			        $(self).pullToRefreshDone(); // 重置下拉刷新
			    }, 2000);   //模拟延迟
		    });
		    
		    $("#tab1").infinite().on("infinite", function() {	    	
				console.log("infiniteScroll.html");
			    var self = this;			    
			    if(self.loading) return;
			    self.loading = true;
			    setTimeout(function() {
			    	//formID 在lappmod.js中进行全局变量赋值			    	
			        setAnnList('',lsatID,{"isonLine":true});
			        self.loading = false;
			    }, 2000);   //模拟延迟
		    });
		    
		    $("#J_searchForm").submit(function(e){
				if(isOnline()){					
				
				 	if($("#search_input").val()){
				 		var val = $("#search_input").val();
				 		sessionStorage.setItem("SEARCH",val);
				 		window.location.href = "#search";
				 	}else{
				 		//alert("请输入搜索内容");
				 		NativeInteractive.toast({"message":"请输入搜索内容"});
				 		return false;
				 	}
			 	}else{
			 		NativeInteractive.toast({"message":"网络不畅，请检查网络"});
					return false;
			 	}
			 	return false;
			});
		    
	  	}
	}else{
		$("#J_searchForm").submit(function(e){ 
			//alert("网络不畅，请检查网络");
			NativeInteractive.toast({"message":"网络不畅，请检查网络"});
			return false;
		});
		$(".weui-pull-to-refresh-layer").css("display","none");
		//OnAppCacheFetchCb();
		NativeInteractive.appCacheFetch({"keys":"annList"});
	}
	
	//这里做一个演示，把数据转成字符串在页面弹出
//	var str_para = JSON.stringify(params);	
//	alert("getNetStatus回调函数OnGetNetStatusCb:"+str_para);
}

var search= {};
search.partial = "../announce/temp/search.html";
search.init = function(){
	miniSPA.render("search");
	$("body").css("background-color","#fff");
	var getSearch = sessionStorage.getItem("SEARCH");
	setAnnList(getSearch,"0",{"isonLine":true});
	//此处开始为下拉刷新与上拉加载的代码	
	if($("#page-ptr-navbar")[0]) {
		
		    $("#tab1").pullToRefresh().on("pull-to-refresh", function() {
		    var self = this;
		    var ele = $(self).find(".annList");
		    
		    setTimeout(function() {
		      	window.location.reload();
		        $(self).pullToRefreshDone(); // 重置下拉刷新
		    }, 2000);   //模拟延迟
	    });
	    
	    $("#tab1").infinite().on("infinite", function() {	    	
			console.log("infiniteScroll.html");
		    var self = this;
		    var ele = $(self).find(".annList");
		    if(self.loading) return;
		    self.loading = true;
		    setTimeout(function() {
		    	//formID 在lappmod.js中进行全局变量赋值
		    	var getSearch = sessionStorage.getItem("SEARCH");
		        setAnnList(getSearch,lsatID,{"isonLine":true});
		       self.loading = false;
		    }, 2000);   //模拟延迟
	    });
	    
  	}
	
	$("#search_cancel").on("click",function(){
		//alert(123);
		window.history.go(-1);
	});
	
	$("#J_searchForm").submit(function(e){
		
		if(isOnline()){
			if($("#search_input").val()){
				$("#annList").html("");
				var val = $("#search_input").val();
				sessionStorage.setItem("SEARCH",val);
				setAnnList(val,"0",{"isonLine":true});
			}else{
				//alert("请输入搜索内容");
				NativeInteractive.toast({"message":"请输入搜索内容"});
			 	return false;
			}
		}else{
			NativeInteractive.toast({"message":"网络不畅，请检查网络"});
			return false;
		}
		return false;
	});
	
}

var content= {};
content.partial = "../announce/temp/content.html";
content.init = function(){
	miniSPA.render("content");
	$("body").css("background-color","#fff");
	var nid = content.parame;
	if( isOnline()  ){
		setContent(nid,{"isonLine":true});
	}else{
		NativeInteractive.appCacheFetch({"keys":"annList","callback":"OnAppCacheFetchCbContent"});		
	}
	$("#J_confirm").on("click",function(){
		changeReadType(nid,2);
		$.toast("已确认");
		$(this).css("display","none");
		$("#J_confirmed").css("display","inline-block");
	});
	$("#J_delete").on("click",function(){
		$.confirm("删除后内容及附件将不能恢复", "确认删除？",function(){
			delAnn(nid);
			$.toast("已经删除!");
			window.location.replace("#home");
			}, function() {
			//取消操作
		});
	});
	$(".attchIteam").each(function(){
		var obj = this;
		$(obj).on("click",function(){
			if( isOnline() ){
				var name = $(this).attr("data-name"),
				path = $(this).attr("data-path"),
				size = $(this).attr("data-size");
				//console.log(path);
				var parameter = {
					"fileName":name,
					"fileID":Date.parse(new Date()),
					"taskID":Date.parse(new Date()),
					"size":size,
					"path":path,
					"isAutoDownload":0,
					"isAutoPreView":0,
					"callback":"OnDownloadCb"
				};
				NativeInteractive.download(parameter);
			}else{
				NativeInteractive.toast({"message":"网络不畅，请稍后重试"});	
			}
			
		});
	});
}

function OnAppCacheFetchCbContent(datas){
	//alert("OnAppCacheFetchCbContent datas:"+datas);
	var status = datas.result.status,
		params = datas.result.params;
	//这里做一个演示，把数据转成字符串在页面弹出
	if(params.data){
		var datastr = params.data;
		var data = utf8to16(base64decode(datastr));
		var nid = content.parame;
		//alert(nid+"OnAppCacheFetchCbContent:"+data);
		//setAnnList("","0",{"isonLine":false,"data":JSON.parse(data)});
		setContent(nid,{"isonLine":false,"data":JSON.parse(data)});
		$("#J_delete").css("display","none");
		//alert(123);
	}else{
		window.location.href('#noweb');
	}
}
	
var member= {};
member.partial = "../announce/temp/member.html";
member.init = function(){
	miniSPA.render("member");
	$("body").css("background-color","#fff");
	var nid = member.parame;
	console.log(nid);
	setMember(nid);
	
}
	
var upload= {};
upload.partial = "../announce/temp/upload.html";
upload.init = function(){
	miniSPA.appendScript("../script/lib/jquery.validate");
	miniSPA.appendScript("../script/lib/jquery.validate.zh");
	miniSPA.render("upload");
	$("body").css("background-color","#F2F2F2");
	var checkonline = isOnline();
	//alert(checkonline);
	if( !checkonline ){
		$("input[type='submit']").attr("disabled","true").val("请检查网络后,返回重试")
	}
	
	//@选择联系人
	$("#chooseReciver").on("click",function(){
		selectContacts();
	});
	//@选择公告图片	
	$("#chooseImg").on("click",function(){		
		chooseSheetPhoto();
	});
	//@添加附件 附件至多由AttachLimit决定
	$("#chooseAttch").on("click",function(){		
		var attachCount = parseInt($("#chooseAttch").attr("data-attachCount"))+1;
		// @ AttachLimit 全局变量在 lappmod.js中定义
		if(attachCount>AttachLimit){
			NativeInteractive.toast({"message":"只能上传3个附件"});	
			return false;
		}else{
			//@ FileFlag 全局变量在 lappmod.js中 处理兼容uploadFile callback返回2次成功的bug
			FileFlag = true;
			$("#chooseAttch").attr("data-attachCount",attachCount);
			uploadFile();
		}
		
	});
	//@ 删除 附件
	$("#attchElem").on('click','.J_c_attchDel',function(){
		var obj = this;
		var attachCount = parseInt($("#chooseAttch").attr("data-attachCount"));
		$.confirm("确认删除此附件吗", "确认删除？",function(){			
			$("#chooseAttch").attr("data-attachCount",attachCount-1);
			$(obj).parent().next("input").remove();
			$(obj).parent().remove();
			$.toast("已经删除!");
			}, function() {
			//取消操作
		});
	});
	
	$("#J_formValidate").validate({
		rules: {
			title:"required",
			chooseReciver:"required",
			content:"required",
			topTime:{
				digits:true
			}
		},
		messages:{
			title:"标题不能为空",
			chooseReciver:"接收人不能为空",
			content:"内容不能为空"
		},
		submitHandler:function(form){
			if(isOnline()){
				noticeSave();
			}else{
				NativeInteractive.toast({"message":"网络不畅，检查网络后再试"});
				return false;
			}
            
        }
        
	});
}
		
	
	
	
	
	
