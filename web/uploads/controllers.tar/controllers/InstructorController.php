<?php

namespace app\modules\leave\controllers;

class InstructorController extends \yii\rest\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
