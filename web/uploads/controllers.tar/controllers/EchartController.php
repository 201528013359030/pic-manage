<?php

namespace app\modules\leave\controllers;

use yii\web\Controller;
use app\models\LeaveHistory;
use app\models\Studentinfo;
use app\models\Teacherinfo;
use app\models\LeaveInstructor;
use app\models\IctWebService;
use app\models\LeaveAudit;
use app\models\LeaveUnit;
use app\models\LeaveSyllabus;


class EchartController extends Controller
{
    public $enableCsrfValidation = false;//yii默认表单csrf验证，如果post不带改参数会报错！
    public $layout  = false;
    public $startWeek = '2016-03-07';
    public $term = "2015-2016学年第二学期";
    public $processDefinitionKey  = "LeaveBill";
    public $leaveNotice  = "请假通知";
    public $urlAudit = "/leave/web/index.php?r=leave/audit/content&uid=&eguid=&auth_token=&id=";
   // public $institute = ["临床学院",'护理学院','眼视光系','管理系','药学系','心理学系','生物医学工程系','艺术学院'];
    public $institute =  ["艺术学院",'生物医学工程系','心理系','药学院','管理系','眼视光系','护理学院','临床学院'];
    public $year =  ["2011",'2012','2013','2014','2015'];
    public function actionSearch()
    {
        $institute = \Yii::$app->request->post('institute');
        $year = \Yii::$app->request->post('year');
        if(!$year){
            $year = '2015';
        }
        $connection = \Yii::$app->db;
        if(!$institute){
            $command = $connection->createCommand("select * from studentinfo group by `major`");
        }else{
            $command = $connection->createCommand("select * from studentinfo where institute='".$institute."' group by `major`");
        }
        $majorList = $command->queryAll();
        foreach($majorList as $m){
            $major[] = $m['major'];
        }
     //   print_r($echart);
        return $this->render('search',["institute"=>$this->institute,
                                    "year"=>$this->year,
                                    "sYear"=>$year,
                                    "sInstitute"=>$institute,
                                    "major"=>$major]);
    }
    //
    public function actionYear()
    {
        foreach($this->year as $y){
            $count = LeaveHistory::find()->where(['year'=>$y,'state'=>'2'])->count();
            $echart[] = ["name"=>$y.'级',"count"=>$count];
        }
 //       print_r($echart);
        return $this->render('institute',["echart"=>$echart,"term"=>$this->term,"title"=>"年级统计"]);
    }
    public function actionInstitute()
    {
        foreach($this->institute as $i){
            $count = LeaveHistory::find()->where(['institute'=>$i,'state'=>'2'])->count();
            $echart[] = ["name"=>$i,"count"=>$count];
        }
 //       print_r($echart);
        return $this->render('institute',["echart"=>$echart,"term"=>$this->term,"title"=>"院系统计"]);
    }
    public function actionMajor()
    {
        $keys = [];
        $connection = \Yii::$app->db;
        $command = $connection->createCommand("select * from studentinfo where  institute<>'研发中心'  group by `institute`");
        $institute = $command->queryAll();
     //   print_r($institute);
        foreach($institute as $i){
            $whereStr = " institute='".$i['institute']."'";
            $command = $connection->createCommand("select * from studentinfo where $whereStr  group by `major`");
            $majorList = $command->queryAll();
       //     print_r($majorList);
            foreach($majorList as $m){
                $command = $connection->createCommand("select * from leave_history where state=2 and major='".$m['major']."' ");
                $echart = $command->queryAll();
                $k = base64_encode($m['institute'].$m['major']);
                if(!isset($keys[$k])){
                    $keys[$k] = count($keys);
                }
                $k = $keys[$k];
                $class[$k] = ['name'=>$m['major'],'count'=>count($echart)];
            }
        }
        return $this->render('institute',["echart"=>$class,"term"=>$this->term,"title"=>"专业统计"]);
    }
    public function actionClass()
    {
        $beginDate = strtotime(date("Y-m-d"));
        $endDate = strtotime(date('Y-m-01',$beginDate)." +1 month -1 day");
        $institute = \Yii::$app->request->post('institute');
        $major = \Yii::$app->request->post('major');
        $year = \Yii::$app->request->post('year');
        $connection = \Yii::$app->db;
        $class = [];
        $whereStr = "where uid is not null";
        if($institute){
            $whereStr = $whereStr." and institute='$institute'";
        }
        if($major){
            $whereStr = $whereStr." and major='$major'";
        }
        if($year){
            $whereStr = $whereStr." and year='$year'";
        }
//        print_r($whereStr);
        $command = $connection->createCommand("select * from studentinfo $whereStr group by `institute` ORDER BY `year` DESC");
        $institute = $command->queryAll();
//        print_r($institute);
  //      return;
  //      $echart = LeaveHistory::find()->where(1)->asArray()->all();
        $whereStr = $whereStr." and state='2'";
        $command = $connection->createCommand("select * from leave_history $whereStr");
        $echart = $command->queryAll();
    //    print_r($echart);
  //      return;
        $keys = [];
        foreach($institute as $i){
            if($major){
                $whereStr =" major='$major'";
            }else{
                $whereStr = " institute='".$i['institute']."'";
            }
            if($year){
                $whereStr = $whereStr." and year='$year'";
            }
           // print_r($whereStr);
            $command = $connection->createCommand("select * from studentinfo where $whereStr  group by `major` ORDER BY `year` DESC,`grade` DESC");
            $majorList = $command->queryAll();
       //     print_r($majorList);
            foreach($majorList as $m){
                if($year){
       //             $whereStr = $whereStr." and year='$year'";
                    $yearList[] = $year;
                }else{
                    $yearList[] = "2015";
                    $yearList[] = "2014";
                    $yearList[] = "2013";
                    $yearList[] = "2012";
                    $yearList[] = "2011";
                }
                foreach($yearList as $y){
                    $whereStr = "year<>0 and major='".$m['major']."'";
                    $whereStr = $whereStr." and year='$y'";
                    $command = $connection->createCommand("select * from studentinfo where $whereStr group by `grade` ORDER BY `year` DESC,`grade` DESC");
                    $grade = $command->queryAll();
          //          print_r($grade);
                    foreach($grade as $g){
                        $k = base64_encode($g['institute'].$g['major'].$g['year'].$g['grade']);
                        if(!isset($keys[$k])){
                            $keys[$k] = count($keys);
                        }
                        $k = $keys[$k];
                        //$class[$k] = ['name'=>substr($g['year'],-2).$g['major'].$g['grade'].'班','count'=>isset($class[$k]['count'])?++$class[$k]['count']:0];
                        $class[$k] = ['name'=>$g['major']."\\n".substr($g['year'],-2).sprintf("%02d",$g['grade']).'班','count'=>0];
                    }
                
                }
            }
        }
     //   print_r($class);
      //  return;
        foreach($echart as $e){
            $k = base64_encode($e['institute'].$e['major'].$e['year'].$e['grade']);
            if(!isset($keys[$k])){
                $keys[$k] = count($keys);
            }
            $k = $keys[$k];
            $class[$k] = ['name'=>$e['major']."\\n".substr($e['year'],-2).sprintf("%02d",$e['grade']).'班','count'=>isset($class[$k]['count'])?++$class[$k]['count']:0];
        }
  //      print_r(count($class));
        return $this->render('institute',["echart"=>$class,"term"=>$this->term,'title'=>"班级统计"]);
    }
    public function actionIndex()
    {
        return $this->render('index');
    }
}
