<?php

namespace app\modules\leave\controllers;
use yii\web\Controller;
use app\models\Studentinfo;
use app\models\IctWebService;
class CogradientController extends Controller
{
    public function actionIndex()
    {
    	$studentModel=new Studentinfo();
    	$sql="select * from studentinfo where 1";
    	//     	$sql="select * from (select * from (select * from leave_unit where FROM_UNIXTIME(date,'%Y%m%d')='".$today."' and teacher_no='".$teacher_no."') t1 join (select * from leave_history) t2 join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid order by t2.id) t4 where t4.unit in(select unit from t4 group by unit having count(*)>1)";
    	$result = \yii::$app->db->createCommand($sql);
    	$studentArr= $result->queryAll();
    
    	for($i=0;$i<count($studentArr);$i++){
    		if(empty($studentArr[$i]["year"])){
    			$uid=$studentArr[$i]["uid"];
    			$grade=$this->getGrade($uid);
    			 
    			$studentinfo=Studentinfo::findOne([
    					'uid'=>$uid
    					]);
    			$studentinfo->year=$grade;
    			$studentinfo->save();
    		}

    /* 		$connection = \Yii::$app->db;
    		$command = $connection->createCommand("update  studentinfo set year='".$grade."' where uid='".$uid."'");
    		$command->execute(); */

    		//通过id找到那条数据
// 		$studentinfo=Studentinfo::findOne([
// 					'uid'=>$uid
//   			]);  	
//   			print_r($studentinfo);
//   			return; 

//     		$studentinfo->year=$grade;
    	/* 	print_r($studentModel);
    		return ; */
//     		$studentinfo->save();
    	}
        return $this->render('index');
    }
    public function getGrade($uid){
    	$iws = new IctWebService();
    	$iws->getAdminToken();
    	$result = $iws->getNodeInfo($uid,['departmentnumber']);
    	$class = $result['result']['0']['data']['departmentnumber'][0];
    	$grade = substr($class,0,4);
    	return $grade;
    }

}
