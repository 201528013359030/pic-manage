<?php

namespace app\modules\leave\controllers;
use yii\web\Controller;
use  app\models\LeaveUnit;
use app\models\IctWebService;
// use app\modules\leave\controllers\StudentController;
class LeaveInstructorController extends Controller
{
     public $layout=false;
    public function actionIndex()
    {
    	$teacher_no= \Yii::$app->request->get('tid');
//     	$teacher_no="0160";
    	$today=date("Ymd",time());     
//     	$today="20151124";
    	$today =  strtotime($today);                         //当天的时间戳
//     	print_r($today);
    	$LeaveUnit=new LeaveUnit();
    	//先获取分组数据：
//     	$sql="select distinct t1.major,t1.year,t3.unit from studentinfo t1 join leave_history t2 on t1.uid = t2.uid join leave_unit t3 on t2.id = t3.leave_id";
    	$group_sql="select distinct t1.setsuji,t1.course,t3.year,t3.major,t3.grade from (select * from leave_unit where date='".$today."'  and find_in_set('".$teacher_no."',teacher_no) and status='0' ) t1 join (select * from leave_history) t2 join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid";
//     	$sql="select * from (select * from (select * from leave_unit where FROM_UNIXTIME(date,'%Y%m%d')='".$today."' and teacher_no='".$teacher_no."') t1 join (select * from leave_history) t2 join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid order by t2.id) t4 where t4.unit in(select unit from t4 group by unit having count(*)>1)";
    	$result = \yii::$app->db->createCommand($group_sql);
    	$groupArr = $result->queryAll();                      //得到请假的分组数组      包含年级、专业、班级、节次
/* 	print_r($groupArr);
    	return  */; 
    	$array=array();
    	$i=0;
 		foreach ($groupArr as $group){                       //对分组进行循环，取出每组的请假的学生的信息
    		$stu_sql="select * from(select t1.setsuji,t1.course,t1.leave_id,t2.reasons,t2.leave_day,t2.leave_type,t2.state,t3.major,t3.year,t3.grade,t3.sName from (select * from leave_unit where  find_in_set('".$teacher_no."',teacher_no) and date='".$today."' and status='0') t1 join (select * from leave_history ) t2 join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid order by t2.id) t where  t.year = '".$group["year"]."' and t.major = '".$group["major"]."' and t.grade='".$group["grade"]."' and t.setsuji='".$group["setsuji"]."'";
//     		$stu_sql="select * from  (select t1.uid,t1.major,t1.year,t1.grade,t1.sName,t2.leave_day,t2.leave_type,t3.setsuji,t3.course from studentinfo t1 join leave_history t2 on t1.uid = t2.uid join leave_unit t3 on t2.id = t3.leave_id) t where t.year = '".$group["year"]."' and t.major = '".$group["major"]."' and t.grade='".$group["grade"]."' and t.setsuji='".$group["setsuji"]."'";
    		$stu_result = \yii::$app->db->createCommand($stu_sql);
    		$studentArr = $stu_result->queryAll();   
    		$key=$group["year"].$group["major"].$group["grade"]."班"." ".$group["setsuji"];
    		$array[$i]=$studentArr;
    		$i++;	
    	}
    /* 	print_r($array);
    	return ; */
    	/**
    	 * 按周几查询
    	 * */
    	$date = date("Y-m-d");
    	$first=1;                                            // 1 表示每周星期一为开始时间，0表示每周日为开始时间
    	$w = date("w", strtotime($date));  //获取当前是本周的第几天，周日是 0，周一 到周六是 1 -6
    	$d = $w ? $w - $first : 6;                  //如果是周日 -6天
    	$now_start = date("Y-m-d", strtotime("$date -".$d." days"));    //本周开始时间
    	$now_time =  strtotime($now_start);         //本周起始时间戳
    	$end_d=$w-7;
    	$now_end = date("Y-m-d", strtotime("$date -".$end_d." days"));
 
    	$now_end =  strtotime($now_end);
    	//step1.按照星期几先进行分组：                //找出本周内的周几有请假的
    	$weekgroup_sql="select distinct date from leave_unit where find_in_set('".$teacher_no."',teacher_no) and status='0' and date between '".$now_time."' and '".$now_end."' order by date asc";
//     	$weekgroup_sql="select distinct t2.start_time from (select * from leave_unit where  teacher_no='".$teacher_no."') t1 join (select * from leave_history where end_time between '".$now_time."' and '".$now_end."' or start_time between  '".$now_time."' and '".$now_end."' or (start_time < '".$now_time."' and end_time >'".$now_end."')) t2 join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid";
    	$week_result = \yii::$app->db->createCommand($weekgroup_sql);
    	$weekgroupArr = $week_result->queryAll();                      //得到请假的分组数组      包含年级、专业、班级、节次
   /*      print_r($weekgroupArr);
        return ; */
    	$weekarray=array();
    	$j=0;
    	$w_stu_array=array();
    	foreach ($weekgroupArr as $week){                                   //周一
    		//再查按年级节次，班级分类的表头分组
    		$week_sql="select distinct t1.setsuji,t1.course,t1.date,t3.year,t3.major,t3.grade from (select * from leave_unit where find_in_set('".$teacher_no."',teacher_no) and status='0' and date='".$week["date"]."') t1 join (select * from leave_history  where   end_time between '".$now_time."' and '".$now_end."' or start_time between  '".$now_time."' and '".$now_end."' or (start_time < '".$now_time."' and end_time >'".$now_end."')) t2  join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid";
    		//     	$sql="select * from (select * from (select * from leave_unit where FROM_UNIXTIME(date,'%Y%m%d')='".$today."' and teacher_no='".$teacher_no."') t1 join (select * from leave_history) t2 join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid order by t2.id) t4 where t4.unit in(select unit from t4 group by unit having count(*)>1)";
    		$w_result = \yii::$app->db->createCommand($week_sql);
    		$weekArr = $w_result->queryAll();
    		//再对表头进行一次循环，查出该年级、专业、班级、节次的学生信息：
//     		$weekarray[$j]=$weekArr;                                     //表示周一的所有分组信息
    		
 		/* 	print_r($week_sql);
    		return ;  */ 
    		foreach ($weekArr as $key=>$value){
    				$w_stu_sql="select * from(select t1.setsuji,t1.course,t1.date,t1.leave_id,t2.reasons,t2.leave_day,t2.leave_type,t2.start_time,t2.state,t3.major,t3.year,t3.grade,t3.sName from (select * from leave_unit where  find_in_set('".$teacher_no."',teacher_no) and status='0' and date='".$week["date"]."') t1 join (select * from leave_history where end_time between '".$now_time."' and '".$now_end."' or start_time between  '".$now_time."' and '".$now_end."' or (start_time < '".$now_time."' and end_time >'".$now_end."')) t2 join (select * from studentinfo) t3 where t1.leave_id=t2.id  and t2.uid=t3.uid order by t2.id) t where  t.year = '".$value["year"]."' and t.major = '".$value["major"]."' and t.grade='".$value["grade"]."' and t.setsuji='".$value["setsuji"]."'";
    				$w_stu_result = \yii::$app->db->createCommand($w_stu_sql);
    				$w_studentArr = $w_stu_result->queryAll();
    				$starttime=$week['date'];
    				$w = date("w", $starttime);
    				$char = array("周日7","周一1","周二2","周三3","周四4","周五5","周六6");
    				$weekstr=$char[$w];			 
    				$w_stu_array[$weekstr][$key]=$w_studentArr;                                      //三维数组 key代表周几，二维代表年级，专业班级节次
    		}
    		$j++;	
    	}  	
	/* print_r($w_stu_array);
    	return ;  */
    	$typeStr = ["","事","病","婚","丧","年","其他"];
    	$typeclass=["","ic_shi","ic_ill","ic_marry","ic_die","ic_year","ic_other"];
    	return $this->render('index',['stuList'=>$array,'w_stu_array'=>$w_stu_array,'typeStr'=>$typeStr,'typeclass'=>$typeclass]);
    }
    public function getGrade($uid){
    	$iws = new IctWebService();
    	$iws->getAdminToken();
    	$result = $iws->getNodeInfo($uid,['departmentnumber']);
    	$class = $result['result']['0']['data']['departmentnumber'][0];
    	$grade = substr($class,0,4);
    	return $grade;
    }

}
