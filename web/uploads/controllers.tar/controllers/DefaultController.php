<?php

namespace app\modules\leave\controllers;

use yii\web\Controller;
use app\models\IctWebService;
use app\models\Studentinfo;

class DefaultController extends Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }
    public function actionNotice(){
        return;
        $connection = \Yii::$app->edb;
        $command = $connection->createCommand('SELECT * FROM ict2users_password WHERE 1');
        $user = $command->queryAll();
         $iws = new IctWebService();
        foreach($user as $u){
            $mobile = $u['user'];
            $pwd = $u['password'];
            $text = "小何号上线了，手机直接访问http://xapp.hevision.com下载APP，用户账号为您的手机号码，密码默认为".$pwd."，登陆后请尽快修改密码。技术支持：024-62836992";
            $iws->send_message_via_hevision(["$mobile"],$text);
        }
    }
    public function actionNotice15(){
        $user = Studentinfo::find()->where(['year'=>"2015"])->asArray()->all();
        $iws = new IctWebService();
        foreach($user as $u){
            $mobile = $u['mobile'];
            $mobileList[] = $mobile;
        }
        $text = "小何号新版本发布了，手机直接访问http://xapp.hevision.com下载APP。技术支持：024-62836992";
        //$iws->send_message_via_hevision($mobileList,$text);
        print_r($mobileList);
        return;
    }
}
