<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

$this->title = $name;
if($message == "10001"){
    $message = "认证信息错误或已过期，请尝试重新打开。";
}
?>
<script>
</script>
<div style="text-align:center;padding-top:100px;">
    <?=$message?>
</div>
