<?php
use yii\helpers\Html;
use app\assets\AppAsset;
use yii\widgets\ActiveForm;
?>
   <div class="dl-log">欢迎您，
        <span class="">
        	<?=Yii::$app->user->identity->username?>
        </span>  
    </div>
