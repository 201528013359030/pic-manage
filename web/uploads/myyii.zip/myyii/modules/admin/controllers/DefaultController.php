<?php

namespace app\modules\admin\controllers;
use yii;
use yii\web\Controller;

class DefaultController extends Controller
{

	public $enableCsrfValidation = false;//yii默认表单csrf验证，如果post不带改参数会报错！
    public $layout  = 'main';
    public function actionIndex()
    {	
    //	throw new \yii\web\HttpException(200,'异常信息');
    	Yii::info(["日志",123]);
        return $this->render('index');
    }
}
