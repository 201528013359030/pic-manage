<?php

namespace app\modules\admin;

class index extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\admin\controllers';

    public function init()
    {
        parent::init();
        \Yii::$app->params['urlSubflag'] = '&subflag='.\Yii::$app->request->get('subflag');
        // custom initialization code goes here
    }
}
