<?php

namespace app\modules\webService;

class api extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\webService\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
