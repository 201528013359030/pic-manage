<?php
namespace app\modules\webService\models;
use app\modules\webService\models\Wechat;
use app\modules\webService\models\WechatToken;
use app\models\EnterpriseInfo;

class Basic extends \app\modules\webService\models\WebService
{
	function __construct(){
        parent::init();
        parent::registerApi(
            "get.apps",
            "getApps",
            [
                "enterprisId"=>['type'=>'string']
            ],
            false
        );
	}
    public function getApps($telphone,$wid,$frequency,$ip){
        return 'hehe';
    }
   
}

?>
