<?php

namespace app\modules\webService\controllers;
use Yii;
use app\modules\webService\models\Basic;

class MainController extends \yii\rest\Controller
{
    public function actionApi($method)
    {
        $webService = new Basic;
        $webService->setMethod($method);
        return $webService->run();
    }
}
