<?php

$params = require(__DIR__ . '/params.php');
$response = require(__DIR__ . '/response.php');

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'modules' => [
        'webService' => [
            'class' => 'app\modules\webService\api',
        ],
        'admin' => [
            'class' => 'app\modules\admin\index',
        ],
    ],

    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => '5ZSVNcMs3wP00Ss5zrnK3BsJe6uBXDT7',
        ],
        'response' => [
            'class' => 'yii\web\Response',
            'on beforeSend' => $response,
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\models\User',//模型自动登录
            'enableAutoLogin' => true,
            'loginUrl'=>['admin/index/login'],//定义后台默认登录界面[权限不足跳到该页]
        ],
        
        'errorHandler' => [
            //'errorAction' => 'site/error',
            // 'errorAction' => 'webService/main/error',
			'errorAction' => 'error/index',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => false,
           
            'transport' => [  
                'class' => 'Swift_SmtpTransport',  
                'host' => 'smtp.163.com',  
                'username' => 'sipsysict@163.com',  
                'password' => 's1psys@sict',  
                'port' => '25',  
                'encryption' => 'tls',  

            ],   
            'messageConfig'=>[  
                'charset'=>'UTF-8',  
                'from'=>['sipsysict@163.com'=>'YiiLog']  
            ],
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error'],
                ],/*
                'file' => [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['trace', 'info','error', 'warning'],
                    'categories' => ['yii\*'],
                ],*/
                [
                    'class' => 'yii\log\EmailTarget',
                    'levels' => ['warning'],
                    'message' => [
                        'to' => ['zhengzhaoduo@sict.ac.cn'],
                        'subject' => '来自 example.com 的新日志消息',
                    ],
                ],
            ],
        ],
        'db' => require(__DIR__ . '/db.php'),
        'redis' => [
            'class' => 'yii\redis\Connection',
            'hostname' => 'localhost',
         //   'port' => 6379,
            'port' => 48720,
            'database' => 0,
        ],
        'es' => [
            'class' => 'yii\elasticsearch\Connection',
            'nodes' => [
                ['http_address' => '127.0.0.1:9200'],
            ],
        ],
        'elasticsearch' => [
            'class' => 'yii\elasticsearch\Connection',
            'nodes' => [
                ['http_address' => '127.0.0.1:9200'],
            ],
        ],
    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = 'yii\debug\Module';

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii']['class'] = 'yii\gii\Module';
    $config['modules']['gii']['allowedIPs'] = ['127.0.0.1', '::1', '192.168.139.*'];
}

return $config;
