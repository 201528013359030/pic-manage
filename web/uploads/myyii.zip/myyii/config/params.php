<?php

return [
    'adminEmail' => 'admin@example.com',
    'wechat' =>[
        'options'=>[
            'token'=>'qifahao_TELPO', //填写你设定的key
            'appid'=>'wx2841427ccd2e3857',//???发???凭???
            'appsecret'=>'439551496c4602a502bd1d2c4d370a76', //???发???凭???
            'debug'=>true,
            'logcallback'=>'./log.text' 
        ],
    ],
    'path'=>'http://'.$_SERVER['HTTP_HOST'],
    'menu'=>[
        '01'=>['main'=>'平台管理',
            'img'=>'images/mainmenu01.png',
            'sub'=>[
                '01'=>['name'=>'企业接入','url'=>'index.php?r=admin/enterprise/index'],
                '02'=>['name'=>'微信绑定','url'=>'index.php?r=admin/bind/index'],
                '03'=>['name'=>'消息推送','url'=>'index.php?r=admin/imlog/index'],
            ]
        ]
    ],
    'urlSubflag'=>'&subflag=0101',
];
