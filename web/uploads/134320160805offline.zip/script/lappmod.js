var FileFlag = true;
var FirstVisit = true;
var Limit = 10;
var AttachLimit = 3;
var lsatID = "";
function setAnnList(search,formID,setting){
	
	var search = search;
	var infos='';
	if(setting.isonLine){
		
		var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=notices.get";		
		var arr = {
			"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
			"search":search,
			"fromID":formID,
			"limit":Limit,
			"uid":sessionStorage.getItem("NATIVE_UID")
		};
		var data = getJsonResult(url,arr);
		infos = data.info;
		
//		if( search!='' && infos.length==0){
//			var nodata = dataEmpty("nodata","没有搜索到公告","没有搜索到相关公告");
//			$("#annList").html( nodata );
//			$(".resultEnd").html('');
//			
//			return false;
//		}

		//@ 在线的时候存储在本地数据
		if( FirstVisit ){
			if( search=='' && infos.length==0){
				var nodata = dataEmpty("nodata","暂无公告","还没有公告信息");
				$("#annList").html( nodata );
				$(".resultEnd").html('');
				if(cansave()||isgroupOwner()){
					$("#page-ptr-navbar").append('<div class="endButton"><a href="#upload" id="sendAnn">发布公告</a></div>');
				}
				return false;
			}
			var str_infos = JSON.stringify(infos);
			//sessionStorage.setItem("annList",str_infos);
			var str_64_infos = base64encode(utf16to8(str_infos));
			console.log("FirstVisit str_infos:"+str_infos);
			NativeInteractive.appCacheStore({"keys":"annList","datas":str_64_infos});
			FirstVisit = false;	
		}
		
		if(infos.length<Limit){
			$(".resultEnd").html('');
		}else{
			$(".resultEnd").html('<div class="infinite-preloader"></div>正在加载...');
		}
		
		//if(infos.length)
	
	}else{
		//@ 处理离线时赋值的情况
		if(setting.data){
			infos = setting.data;
			$(".resultEnd").html('');
		}else{
			NativeInteractive.toast({"message":"很抱歉，网络不畅！"});		
			return false;
		}
	}
	
	//生成公告列表
	var tpl_annList = $("#tpl_annList").html();
	var html = [];
	var now_time = new Date().getTime()/1000;
	for( var i=0; i<infos.length; i++ ){
		lsatID = infos[i].announce_id;
		var isTop = false;
		if( infos[i].comment_switch==1 ){
			if( infos[i].top_time==null	|| infos[i].top_time>now_time ){
				isTop = true;
			}
		}
				
		var html_ann = tpl_annList
				.replace( /\{id\}/g,infos[i].announce_id )
				.replace( /\{comment_switch\}/g,isTop?"[置顶]":"" )
				.replace( /\{title\}/g,infos[i].title )
				.replace( /\{date\}/g,getUnixTime(infos[i].time) )
				.replace( /\{unview\}/g,infos[i].relation=="unread"?'<span class="ui-badge">new</span>':'' );
		html.push(html_ann);
		
	}

	$("#annList").append( html.join('') );
}

//@ 生成暂无数据与暂无结果页面
function dataEmpty(icon,title,subTitle){
	//console.log(icon+title+subTitle);
	var html = '<div class="weui_msg"><div class="weui_icon_area"><img src="../images/'+icon+'.png" /></div><div class="weui_text_area"><h2 class="weui_msg_title">'+title+'</h2>'
	+'<p class="weui_msg_desc">'+subTitle+'</p></div></div>';
	return html;
}

function setContent(nid,setting){
	var infos='';
	//alert("nid:"+nid+"setContent setting:"+JSON.stringify(setting));
	if(setting.isonLine){
		var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=notice.get";
		var arr = {
			"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
			"nid":nid,
			"uid":sessionStorage.getItem("NATIVE_UID")
		};
		var data = getJsonResult(url,arr);
		infos = data.info;
		console.log("setContent online:"+JSON.stringify(infos));
		//alert("setContent:"+JSON.stringify(infos));
		
		//@ 如果是未读则更改当前状态为已读
		if(infos.relation=="unread"){
			changeReadType(nid,1);
		}
		
	}else{
		var data = setting.data;
		//alert("nid:"+nid+"setContent offline:"+JSON.stringify(data));
		for(var i=0;i<data.length;i++){
			if(data[i].announce_id==nid){
				infos = data[i];
			}
		}
		$(".hide_offLine").css("display","none");
	}
	//alert("setContent:"+JSON.stringify(infos));
	
	//生成公告详细页面
	var tpl_content = $("#tpl_content").html();
	var tpl_attch = $("#tpl_attch").html();
	var html_checkBtn = "";
	var html_del = "";
	var html_attch=[];
	var html = tpl_content
			.replace( /\{title\}/g,infos.title )
			.replace( /\{time\}/g,getUnixTime(infos.time) )
			.replace( /\{sender_name\}/g,infos.sender_name )
			.replace( /\{readCount\}/g,infos.readCount )
			.replace( /\{confirmCount\}/g,infos.confirmCount )
			.replace( /\{content\}/g,infos.content )
			.replace( /\{allCount\}/g,infos.allCount )
			.replace( /\{id\}/g,infos.announce_id );
	//@ 判断是否需要确认，及当前是否已确认
	if(infos.isConfirm==1){
		if(infos.confirm=="no"){
			html_checkBtn = '<a id="J_confirm" href="javascript:void(0);" data-nid='+infos.announce_id+' class="weui_btn weui_btn_blue btnLeft"><span class="fa-icon-check-empty"></span>确认</a>'
		+'<div id="J_confirmed" class="weui_btn weui_btn_disabled weui_btn_default btnLeft" style="display: none;"><span class="fa-icon-check"></span>已确认</div>';
		}else{
			html_checkBtn ='<div id="J_confirmed" class="weui_btn weui_btn_disabled weui_btn_default btnLeft"><span class="fa-icon-check"></span>已确认</div>';
		}		
	}
	//@ 判断是否附件如果有附件则显示附件
	if(/\[/.test(infos.attach)){
		console.log("有附件"+infos.attach);
		var attach = JSON.parse(infos.attach);
		for( var i=0; i<attach.length; i++ ){
			var iteam = tpl_attch
				.replace( /\{path\}/g,attach[i].path )
				.replace( /\{size\}/g,attach[i].size )
				.replace( /\{name\}/g,attach[i].name );
			html_attch.push(iteam);
		}		
	}
	
	//@ 判断是否有删除权限
	if(infos.sender==infos.uid){
		html_del = '<div class="btnBox"><a id="J_delete" data-nid="'+infos.announce_id+'" href="javascript:void(0);" class="weui_btn weui_btn_warn">删除</a></div>';
	}
	
	
	html = html
		.replace( /\{attch_list\}/g,html_attch.join('') )
		.replace( /\{check_button\}/g,html_checkBtn )
		.replace( /\{del_button\}/g,html_del );
	$("#content").html( html );
}

//@ 显示成员列表
function setMember(nid){
	var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=readers.get";
	var arr = {
		"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
		"nid":nid,
		"uid":sessionStorage.getItem("NATIVE_UID")
	};
	var data = getJsonResult(url,arr);
	var infos = data.info;
	console.log(JSON.stringify(infos));
	var tpl_member = $("#tpl_member").html(),
		tpl_member_li = $("#tpl_member_li").html();
	var html_unview_li = [],
		html_view_li = [],
		html_confirm_li = [];
	var html_member = tpl_member
		.replace( /\{allCount\}/g,infos.allCount )
		.replace( /\{readCount\}/g,infos.readCount )
		.replace( /\{confirmCount\}/g,infos.confirmCount );
	console.log(infos.readers);
	if(infos.unReaders.length>0){
		for( var i=0;i<infos.unReaders.length;i++ ){
			var _html = tpl_member_li
			.replace( /\{photo\}/g,checkphoto(infos.photoIp,infos.unReaders[i].photo) )
			.replace( /\{name\}/g,infos.unReaders[i].name );
			html_unview_li.push(_html);
		}
		
	}
	if(infos.readers.length>0){
		for( var i=0;i<infos.readers.length;i++ ){
			var _html = tpl_member_li
			.replace( /\{photo\}/g,checkphoto(infos.photoIp,infos.readers[i].photo) )
			.replace( /\{name\}/g,infos.readers[i].name );
			html_view_li.push(_html);
		}		
	}
	if(infos.confirmers.length>0){
		for( var i=0;i<infos.confirmers.length;i++ ){
			var _html = tpl_member_li
			.replace( /\{photo\}/g,checkphoto(infos.photoIp,infos.confirmers[i].photo) )
			.replace( /\{name\}/g,infos.confirmers[i].name );
			html_confirm_li.push(_html);
		}		
	}
	html_member = html_member
		.replace( /\{unview_list\}/g,html_unview_li.join('') )
		.replace( /\{view_list\}/g,html_view_li.join('') )
		.replace( /\{confirm_list\}/g,html_confirm_li.join('') );
	
	$("#member").html( html_member );
}

//@ 判断传过来的图片的路径，是否有值，是否有serverip 返回对应的默认头像和具体的图片路径
function checkphoto(service,path){
	var src = '../images/icon_male.png';
	if(/php/.test(path)){
		if(/http/.test(path)){
			src = path;
		}else{
			src = service+path;
		}
	}
	return src;
}

//@ 判读是否有发布权限
function cansave(){
	var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=cansave";
	var arr = {
		"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
		"uid":sessionStorage.getItem("NATIVE_UID")
	};
	var data = getJsonResult(url,arr);
	return data.canSave=="yes"?true:false;
}

//@ 判断是否是群主 是群组有权发公告
function isgroupOwner(){
	var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=isgroupowner";
	var arr = {
		"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
		"gid":sessionStorage.getItem("NATIVE_GID"),
		"uid":sessionStorage.getItem("NATIVE_UID")
	};
	var data = getJsonResult(url,arr);
	//alert(data);
	return data.isOwner=="yes"?true:false;
		
}

/**
	@ 更新通知的阅读状态
	action 1 已读 2 已确认
*/
function changeReadType(nid,action){
	var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=alreadyread";
	var arr = {
		"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
		"nid":nid,
		"action":action,
		"uid":sessionStorage.getItem("NATIVE_UID")
	};
	var data = getJsonResult(url,arr);	
}



//@ 删除公告
function delAnn(nid){
	var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=notice.delete";
	var arr = {
		"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
		"nid":nid,
		"uid":sessionStorage.getItem("NATIVE_UID")
	};
	var data = getJsonResult(url,arr);
	console.log("delAnn"+JSON.stringify(data));
}

//@ 发布公告相关

//@ 选择联系人，返回联系人姓名
function selectContacts(){	
	NativeInteractive.selectContacts({"maxCount":999,"tag":"uid,name,mobileNum","callback":"OnSelectContactsCb"});
}
function OnSelectContactsCb(datas){
	var status = datas.result.status,
		params = datas.result.params;	
	//这里做一个演示，把数据转成字符串在页面弹出
	if(status==0){
		var name = [],
			uid = [],
			mobileNum = [];
		var contacts = params.contacts;		
		for(var i=0; i<contacts.length; i++){			
			var _name = contacts[i].contactInfo.name,
				_uid = contacts[i].contactInfo.uid,
				_mobileNum = contacts[i].contactInfo.mobileNum;
			name.push(_name);
			uid.push(_uid);
			mobileNum.push(_mobileNum);
		}
		$("#chooseReciver").val(name.join(","));
		$("#reciverName").val(name.join(","));
		//$("#reciverName").val(mobileNum.join(","));
		$("#reciverId").val(uid.join(","));
	}else{
		NativeInteractive.toast({"message":"很抱歉，请求超时请返回重试"});			
	}
	
}
//@ 选择上传图片
function chooseSheetPhoto(){
	var transferid = parseInt(new Date().getTime()/1000);
	NativeInteractive.chooseSheetPhoto({"webAppTransferID":transferid});
}
function OnChoosePhotoCb(datas){
	var status = datas.result.status,
		params = datas.result.params;
		if(status==0){
			var str_para = JSON.stringify(params);		
			console.log("upload回调函数OnUploadCb:"+str_para+"status:"+status);
			$("#prevContentImg").css("display","none");
			if(params.width>=params.height){
				//横图
				$("#prevContentImg").attr("class","hor");
			}else{
				//竖图
				$("#prevContentImg").attr("class","ver");
			}
			var setting = {
				"uploadUrl":sessionStorage.getItem("SERVER_IP")+"/media_file/",
				"fileID":params.fileID,
				"fileName":params.fileName,
				"taskID":params.webAppTransferID,
				"nativePath":params.nativePath
			}
			//alert(JSON.stringify(setting));
			$.showLoading("图片上传中");
			NativeInteractive.uploadGivenFile(setting);
		}	
}
function OnUploadGivenFileCb(datas){
	//alert("OnUploadGivenFileCb"+JSON.stringify(datas));
	var status = datas.result.status,
		params = datas.result.params;
	if(params){		
		var transferStatus = params.transferStatus;
		
		if(transferStatus=="Success"){
			$.hideLoading();
			$("#prevContentImg").css("display","block").html('<img src="'+params.thumb+'">');
			$("#chooseImg").val("重新上传图片");
			$("#contentImg").val(params.uploadPath);
			var str_para = JSON.stringify(params);
			console.log("OnUploadGivenFileCb 图片已上传:"+str_para);
			
		}
	}
}

function uploadFile(){
	 
	var transferid = parseInt(new Date().getTime()/1000);
	var setting ={ uploadUrl : sessionStorage.getItem("SERVER_IP")+"/media_file/",
		webAppTransferID :transferid,
		taskID : Date.parse(new Date())
		};
	NativeInteractive.upload(setting);
	
}
function OnUploadCb(datas){
	
	var status = datas.result.status,
		params = datas.result.params;		
	if(params){
		var transferStatus = params.transferStatus;
			if(transferStatus=="Success"){
				if(FileFlag){
					$("#attchBox").css("display","block");
					var num = $("#chooseAttch").attr("data-attachCount");
					var box = $("#attchElem");
					var html = '<div class="attchIteam">'
						+'<div class="fl"><span class="fa-icon-file-alt"></span> <span>'+params.fileName+'</span></div>'
						+'<a href="javascript:void(0);" class="fa-icon-remove fr J_c_attchDel"></a>'
					+'</div>'
					+'<input type="hidden" value="'+params.uploadPath+'" data-size="'+params.size+'" data-name="'+params.fileName+'" name="attach'+num+'">';
					box.append(html);
					FileFlag = false;
					var str_para = JSON.stringify(params);
					console.log("OnUploadGivenFileCb 图片已上传:"+str_para);	
				}
					
			}
	}
}

//@ 发布公告
function noticeSave(){
	//@ 获取相应上传参数
	var title       = $("#title").val(),
		content     = $("#content").val(),
		reciverName = $("#reciverName").val(),
		reciverId   = $("#reciverId").val(),
		contentImg  = $("#contentImg").val(),
		attachCount = $("#chooseAttch").attr("data-attachCount"),
		top         = $("input[name='top']").is(':checked')?"on":"",
		confirm     = $("input[name='confirm']").is(':checked')?"on":"",
		topTime     = $("#topTime").val();
	
	var arr = {
		"auth_token":sessionStorage.getItem("NATIVE_AUTH_TOKEN"),
		"title":title,
		"content":content,
		"attach1":"",
		"attach2":"",
		"attach3":"",
		"attachCount":attachCount,
		"contentImg":contentImg,
		"receiverId":reciverId,
		"receiverName":reciverName,
		"photo":"0",
		"filetype":"2",
		"group":"0",
		"UE":"1",
		"uid":sessionStorage.getItem("NATIVE_UID")
	};
	if(top=="on"){
		if(topTime==""||topTime==0){
			NativeInteractive.toast({"message":"请输入置顶天数"});
			return false;
		}else{
			arr["top"]=top;
			arr["topTime"]=topTime;
		}
	}
	if(confirm=="on"){
		arr["confirm"]=confirm;
	}
	if(attachCount>0){
		for(var i=1; i<=attachCount; i++){
			var iteam={};
			iteam["name"]=$("input[name='attach"+i+"']").attr("data-name");
			iteam["size"]=$("input[name='attach"+i+"']").attr("data-size");
			iteam["path"]=$("input[name='attach"+i+"']").val();
			iteam["transferStatus"]="Success";
			arr["attach"+i] = JSON.stringify(iteam);
		}
	}
	console.log(JSON.stringify(arr));
	//@ 提交给server保存
	var url = sessionStorage.getItem("SERVER_IP")+"/notice/web/index.php?r=webService/main/api&method=notice.save";
	
	var data = getJsonResult(url,arr);
	if(data.success==1){
		$.toast("提交成功!");
		window.location.replace("#home");
	}else{
		NativeInteractive.toast({"message":"很抱歉，操作失败稍后再试"});
	}
	
	console.log("获取data"+data);
}


//@ end 发布公告相关

function getUnixTime(timestamp){
	var monthNames = [ "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" ]; 
	var dayNames= ["周日","周一","周二","周三","周四","周五","周六"];
	var ts = timestamp,
	    type = type;
    var t,y,m,d,h,i,s,hour,time, today,year, day,weekTime;  
    t = ts ? new Date(ts*1000) : new Date();  
    y = t.getFullYear();  
    m = t.getMonth()+1;  
    d = t.getDate(); 
    w = t.getDay();
    h = t.getHours();  
    i = t.getMinutes();  
    s = t.getSeconds();
    
    today = new Date();
    year = today.getFullYear();
    day = today.getDate();
    		    
    time = y+'-'+(m<10?'0'+m:m)+'-'+(d<10?'0'+d:d)+' '+(h<10?'0'+h:h)+':'+(i<10?'0'+i:i);
   
    return time; 
}

/**
 * 获取elgg接口数据
 * @param {Object} url--接口地址
 * @param {Object} arr--参数
 * 返回--elgg接口的返回值
 */
function getJsonResult(url,arr){
	var value = "";
	var infos = {"info":JSON.stringify(arr)};
	$.ajax({		
		url:url,
		timeout:5000,
		data:infos,
		type:'post',//HTTP请求类型
		dataType:'json',  
        cache : false,  
		async : false,  
		success:function(data){
			console.log("getJsonResult success:"+JSON.stringify(data));
			//服务器返回响应				
			if(data.status==0){				
				value= data.result;
			}else{
				value="";
				if(data.errorCode){
					if(data.errorCode=="20101"){
						NativeInteractive.toast({"message":"用户认证已超时，请退出后重新进入公告"});	
					}else{
						console.log("sucess value no result:"+JSON.stringify(data));
					}
					
				}
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log("error XMLHttpRequest"+JSON.stringify(XMLHttpRequest));
			var nodata = dataEmpty("nodata","请求超时","很抱歉，请检查您的网络稍后再试");
			$("#J_innerContent").html( nodata );
			
		},
		complete:function(XMLHttpRequest,status){
			if(status=="timeout"){
				NativeInteractive.toast({"message":"很抱歉，请求超时请返回重试"});				
			}
		}
	});
	return value;
}

//@ 判断是否在线
function isOnline(){
	if(navigator.onLine){
		return true;
	}else{
		return false;
	}
}











